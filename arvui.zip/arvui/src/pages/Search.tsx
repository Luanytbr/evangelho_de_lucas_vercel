import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Search as SearchIcon } from "lucide-react";
import { useLocation } from "wouter";
import { useState, useMemo } from "react";

export default function Search() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTheme, setSelectedTheme] = useState<string>("");

  const { data: chapters } = trpc.chapters.list.useQuery();

  // Extrair todos os temas únicos
  const allThemes = useMemo(() => {
    const themes = new Set<string>();
    chapters?.forEach((chapter) => {
      const chapterThemes = chapter.themes ? JSON.parse(chapter.themes) : [];
      chapterThemes.forEach((theme: string) => themes.add(theme));
    });
    return Array.from(themes).sort();
  }, [chapters]);

  // Filtrar capítulos baseado na busca
  const filteredChapters = useMemo(() => {
    if (!chapters) return [];

    return chapters.filter((chapter) => {
      const matchesQuery =
        searchQuery === "" ||
        chapter.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        chapter.context?.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesTheme =
        selectedTheme === "" ||
        (chapter.themes
          ? JSON.parse(chapter.themes).includes(selectedTheme)
          : false);

      return matchesQuery && matchesTheme;
    });
  }, [chapters, searchQuery, selectedTheme]);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Busca Avançada</h1>
          <p className="text-slate-600 mt-2">
            Encontre capítulos por palavra-chave ou tema
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar com Filtros */}
          <div className="lg:col-span-1">
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle className="text-lg">Filtros</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Busca por Palavra-chave */}
                <div>
                  <label className="text-sm font-semibold text-slate-700 block mb-2">
                    Palavra-chave
                  </label>
                  <input
                    type="text"
                    placeholder="Digite uma palavra..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg text-sm"
                  />
                </div>

                {/* Filtro por Tema */}
                <div>
                  <label className="text-sm font-semibold text-slate-700 block mb-2">
                    Tema
                  </label>
                  <select
                    value={selectedTheme}
                    onChange={(e) => setSelectedTheme(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg text-sm"
                  >
                    <option value="">Todos os temas</option>
                    {allThemes.map((theme) => (
                      <option key={theme} value={theme}>
                        {theme}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Botão Limpar */}
                {(searchQuery || selectedTheme) && (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      setSearchQuery("");
                      setSelectedTheme("");
                    }}
                  >
                    Limpar Filtros
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Resultados */}
          <div className="lg:col-span-3">
            <div className="mb-6">
              <h2 className="text-xl font-bold text-slate-900">
                Resultados ({filteredChapters.length})
              </h2>
              {searchQuery && (
                <p className="text-sm text-slate-600 mt-1">
                  Buscando por: <span className="font-semibold">"{searchQuery}"</span>
                </p>
              )}
              {selectedTheme && (
                <p className="text-sm text-slate-600">
                  Tema: <span className="font-semibold">{selectedTheme}</span>
                </p>
              )}
            </div>

            {filteredChapters.length > 0 ? (
              <div className="space-y-4">
                {filteredChapters.map((chapter) => (
                  <Card
                    key={chapter.id}
                    className="cursor-pointer hover:shadow-lg transition-shadow"
                    onClick={() => setLocation(`/capitulos/${chapter.chapterNumber}`)}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg">
                            Capítulo {chapter.chapterNumber}: {chapter.title}
                          </CardTitle>
                        </div>
                        <SearchIcon className="w-5 h-5 text-blue-600 flex-shrink-0 ml-4" />
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-slate-700 leading-relaxed">
                        {chapter.context}
                      </p>

                      {chapter.themes && (
                        <div className="flex flex-wrap gap-2">
                          {JSON.parse(chapter.themes).map((theme: string) => (
                            <span
                              key={theme}
                              className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
                            >
                              {theme}
                            </span>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <SearchIcon className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-600">
                    Nenhum resultado encontrado para sua busca.
                  </p>
                  <p className="text-sm text-slate-500 mt-2">
                    Tente ajustar seus filtros ou palavras-chave.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
