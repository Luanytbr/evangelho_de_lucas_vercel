import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Lightbulb, Target } from "lucide-react";

export default function PracticalApplication() {
  const [, setLocation] = useLocation();

  const applications = [
    {
      teaching: "Amar o Próximo",
      verse: "Lucas 6:27-36",
      problem: "Como amar pessoas que me prejudicam ou que não gosto?",
      biblical: "Jesus ensina a amar até mesmo os inimigos. Não é um sentimento, mas uma escolha de tratar os outros com respeito e compaixão, independentemente de como eles nos tratam.",
      practical: [
        "Identifique alguém que o prejudicou. Escolha orar por essa pessoa todos os dias.",
        "Faça algo gentil por alguém que você normalmente evitaria.",
        "Quando alguém o ofender, responda com paciência em vez de raiva.",
        "Pratique empatia tentando entender a perspectiva da outra pessoa.",
      ],
      challenge: "Esta semana, faça algo gentil por alguém que o prejudicou.",
    },
    {
      teaching: "Generosidade",
      verse: "Lucas 12:33-34",
      problem: "Como posso ser generoso quando tenho dificuldades financeiras?",
      biblical: "Jesus não ensina que você deve dar tudo que tem, mas que deve estar disposto a compartilhar. A generosidade não é sobre quantidade, mas sobre atitude. Um pequeno ato de generosidade pode ter grande impacto.",
      practical: [
        "Identifique algo que você tem em excesso e doe para alguém necessitado.",
        "Procure oportunidades para ajudar alguém sem esperar recompensa.",
        "Doe uma porcentagem de sua renda para ajudar os necessitados.",
        "Compartilhe seu tempo e habilidades com alguém que precisa.",
      ],
      challenge: "Esta semana, doe algo que você valoriza para alguém necessitado.",
    },
    {
      teaching: "Perdão",
      verse: "Lucas 6:37",
      problem: "Como posso perdoar alguém que me prejudicou gravemente?",
      biblical: "O perdão não significa que o que a pessoa fez estava certo. Significa que você escolhe soltar a raiva e o ressentimento para sua própria liberdade. O perdão é mais para você do que para a outra pessoa.",
      practical: [
        "Escreva uma carta para a pessoa que o prejudicou (não precisa enviar).",
        "Identifique como o ressentimento está afetando sua vida.",
        "Ore pela pessoa que o prejudicou, pedindo a Deus que a abençoe.",
        "Procure entender por que a pessoa agiu dessa forma.",
      ],
      challenge: "Esta semana, perdoe alguém que o prejudicou e solte o ressentimento.",
    },
    {
      teaching: "Honestidade",
      verse: "Lucas 16:10-12",
      problem: "Como ser honesto em um mundo onde a desonestidade é comum?",
      biblical: "Jesus ensina que quem é honesto em coisas pequenas será honesto em coisas grandes. A integridade é fundamental para a vida cristã. Ser honesto significa ser confiável e íntegro em todas as situações.",
      practical: [
        "Examine áreas onde você não está sendo completamente honesto.",
        "Confesse qualquer desonestidade e faça reparação se possível.",
        "Pratique dizer a verdade mesmo quando é difícil.",
        "Seja honesto sobre seus sentimentos e motivações.",
      ],
      challenge: "Esta semana, seja completamente honesto em todas as suas interações.",
    },
    {
      teaching: "Humildade",
      verse: "Lucas 18:9-14",
      problem: "Como ser humilde sem parecer fraco ou inferior?",
      biblical: "A humildade não significa pensar que você é inferior. Significa reconhecer que você depende de Deus e que não é melhor que os outros. A verdadeira humildade é força, não fraqueza.",
      practical: [
        "Reconheça suas limitações e fraquezas.",
        "Peça ajuda quando precisar em vez de tentar fazer tudo sozinho.",
        "Elogie os outros e reconheça suas contribuições.",
        "Esteja disposto a aprender com pessoas diferentes de você.",
      ],
      challenge: "Esta semana, admita um erro que cometeu e peça desculpas sinceras.",
    },
    {
      teaching: "Confiança em Deus",
      verse: "Lucas 12:22-31",
      problem: "Como confiar em Deus quando tenho preocupações financeiras e pessoais?",
      biblical: "Jesus ensina que não devemos nos preocupar com as necessidades básicas da vida. Deus cuida de nós. Confiar em Deus significa buscar primeiro Seu reino e Sua justiça, e as outras coisas nos serão acrescentadas.",
      practical: [
        "Identifique suas maiores preocupações e ore a Deus sobre elas.",
        "Procure evidências de como Deus cuidou de você no passado.",
        "Pratique soltar o controle e confiar em Deus.",
        "Busque primeiro o reino de Deus e Sua justiça.",
      ],
      challenge: "Esta semana, escolha uma preocupação e confie completamente em Deus.",
    },
    {
      teaching: "Compaixão pelos Pobres",
      verse: "Lucas 4:18",
      problem: "Como posso ajudar os pobres quando tenho recursos limitados?",
      biblical: "Jesus veio para trazer boas notícias aos pobres. Isso não significa apenas dar dinheiro, mas defender os direitos dos pobres, dignificar sua humanidade e trabalhar pela justiça social.",
      practical: [
        "Voluntarie seu tempo em uma organização que ajuda os pobres.",
        "Aprenda sobre as causas da pobreza em sua comunidade.",
        "Defenda políticas que ajudem os pobres e marginalizados.",
        "Desenvolva relacionamentos com pessoas pobres para entender suas lutas.",
      ],
      challenge: "Esta semana, passe tempo com alguém que é pobre ou marginali zado.",
    },
    {
      teaching: "Oração e Comunhão com Deus",
      verse: "Lucas 11:1-13",
      problem: "Como posso ter uma vida de oração significativa?",
      biblical: "A oração não é apenas pedir a Deus, mas comunhão com Ele. Jesus ensina que devemos orar com persistência, fé e humildade. A oração muda não apenas as circunstâncias, mas também muda a nós.",
      practical: [
        "Estabeleça um tempo específico cada dia para orar.",
        "Comece sua oração com louvor e ação de graças.",
        "Apresente suas petições a Deus com confiança.",
        "Termine sua oração em silêncio, ouvindo a Deus.",
      ],
      challenge: "Esta semana, ore 30 minutos por dia e observe como Deus responde.",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Aplicação Prática</h1>
          <p className="text-slate-600 mt-2">
            Como aplicar os ensinamentos de Jesus na vida moderna
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <Card className="bg-green-50 border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <Target className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-green-900 mb-2">
                    Transforme Conhecimento em Ação
                  </h3>
                  <p className="text-sm text-green-800">
                    Os ensinamentos de Jesus não são apenas para conhecimento intelectual, mas para transformar
                    como vivemos. Cada seção inclui desafios práticos para aplicar na vida.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {applications.map((app, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div>
                  <CardTitle className="text-lg">{app.teaching}</CardTitle>
                  <p className="text-sm text-slate-500 mt-1">{app.verse}</p>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-amber-50 p-4 rounded-lg border-l-4 border-amber-600">
                  <p className="text-sm text-slate-700">
                    <span className="font-semibold">Desafio Comum:</span> {app.problem}
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">
                    O que a Bíblia Diz
                  </h4>
                  <p className="text-slate-700">{app.biblical}</p>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-3">
                    Como Aplicar na Prática
                  </h4>
                  <ul className="space-y-2">
                    {app.practical.map((step, idx) => (
                      <li key={idx} className="flex gap-3">
                        <span className="text-green-600 font-semibold flex-shrink-0">
                          {idx + 1}.
                        </span>
                        <span className="text-slate-700">{step}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-green-50 p-4 rounded-lg border-l-4 border-green-600">
                  <p className="text-sm text-slate-700">
                    <span className="font-semibold">Desafio desta Semana:</span>{" "}
                    {app.challenge}
                  </p>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const chapterNum = parseInt(app.verse.split(":")[0].split(" ")[1]);
                    setLocation(`/capitulos/${chapterNum}`);
                  }}
                >
                  Ler Capítulo Completo
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="pt-8 pb-8">
              <Lightbulb className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                Comece Hoje a Transformar Sua Vida
              </h3>
              <p className="text-slate-600 mb-6">
                Escolha um ensinamento e comece a aplicá-lo em sua vida esta semana. A transformação começa com ação.
              </p>
              <Button onClick={() => setLocation("/capitulos/1")}>
                Explorar os Capítulos
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
