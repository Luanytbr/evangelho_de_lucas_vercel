import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Zap, Sparkles } from "lucide-react";

export default function Miracles() {
  const [, setLocation] = useLocation();

  const miracles = [
    {
      title: "A Pesca Milagrosa",
      chapter: "5:1-11",
      type: "Milagre da Natureza",
      description: "Jesus ordena a Simão Pedro que lance as redes novamente. Apesar de terem trabalhado a noite toda sem pegar nada, as redes se enchem tanto que quase se rasgam.",
      significance: "Demonstra o poder de Jesus sobre a natureza e sua autoridade. Marca o chamado de Pedro como apóstolo.",
    },
    {
      title: "Cura da Sogra de Pedro",
      chapter: "4:38-39",
      type: "Cura de Doença",
      description: "A sogra de Pedro estava com febre alta. Jesus repreende a febre e ela desaparece imediatamente. A mulher se levanta e os serve.",
      significance: "Mostra que Jesus pode curar qualquer doença com uma simples palavra. Demonstra compaixão pelos necessitados.",
    },
    {
      title: "Cura de um Leproso",
      chapter: "5:12-16",
      type: "Cura de Doença",
      description: "Um homem coberto de lepra pede a Jesus para curá-lo. Jesus estende a mão, toca nele e diz: 'Quero, seja curado'. A lepra desaparece imediatamente.",
      significance: "A lepra era considerada incurável. Jesus toca o leproso, algo que era proibido pela lei, mostrando compaixão radical.",
    },
    {
      title: "Cura do Paralítico",
      chapter: "5:17-26",
      type: "Cura de Doença",
      description: "Quatro homens descem um paralítico através do teto para Jesus. Jesus perdoa seus pecados e o cura, permitindo que ele se levante e caminhe.",
      significance: "Mostra que Jesus tem autoridade para perdoar pecados. Demonstra a importância da fé dos amigos.",
    },
    {
      title: "Cura da Mulher Curvada",
      chapter: "13:10-17",
      type: "Cura de Doença",
      description: "Uma mulher estava curvada há 18 anos e não conseguia se endireitar. Jesus a cura no sábado, causando controvérsia com os líderes religiosos.",
      significance: "Mostra que Jesus prioriza a compaixão sobre as regras do sábado. Liberta a mulher de sua aflição.",
    },
    {
      title: "Cura do Homem com Hidropisia",
      chapter: "14:1-6",
      type: "Cura de Doença",
      description: "Um homem com hidropisia (acúmulo de fluido no corpo) aparece diante de Jesus. Jesus o cura e questiona os fariseus sobre curar no sábado.",
      significance: "Continua o tema de Jesus curando no sábado e desafiando as interpretações rígidas da lei.",
    },
    {
      title: "Cura de Dez Leprosos",
      chapter: "17:11-19",
      type: "Cura de Doença",
      description: "Dez leprosos pedem a Jesus para tê-los compaixão. Jesus os cura, mas apenas um volta para agradecer.",
      significance: "Ensina sobre gratidão e reconhecimento das bênçãos de Deus. Mostra que a fé salva.",
    },
    {
      title: "Cura da Orelha do Servo do Sumo Sacerdote",
      chapter: "22:50-51",
      type: "Cura de Doença",
      description: "Durante a prisão de Jesus, Pedro corta a orelha de um servo. Jesus toca a orelha e a cura.",
      significance: "Mesmo durante sua própria prisão, Jesus mostra compaixão e cura seu inimigo.",
    },
    {
      title: "Expulsão de Demônio em Cafarnaum",
      chapter: "4:31-37",
      type: "Expulsão de Demônios",
      description: "Um homem possuído por um demônio grita para Jesus. Jesus repreende o demônio e ele sai do homem.",
      significance: "Mostra a autoridade de Jesus sobre os poderes demoníacos. O povo fica espantado com seu poder.",
    },
    {
      title: "Cura do Gadareno Possuído",
      chapter: "8:26-39",
      type: "Expulsão de Demônios",
      description: "Um homem possuído por muitos demônios vive entre os sepulcros. Jesus expulsa os demônios, que entram em uma manada de porcos.",
      significance: "Mostra o poder de Jesus sobre múltiplos demônios. O homem curado testemunha sobre Jesus em sua cidade.",
    },
    {
      title: "Cura da Filha de Jairo",
      chapter: "8:40-56",
      type: "Ressurreição",
      description: "Jairo, um líder da sinagoga, pede a Jesus para curar sua filha que está morrendo. Jesus a ressuscita dizendo: 'Menina, levanta-te'.",
      significance: "Mostra que Jesus tem poder sobre a morte. Demonstra a importância da fé mesmo quando parece impossível.",
    },
    {
      title: "Ressurreição do Filho da Viúva de Naim",
      chapter: "7:11-17",
      type: "Ressurreição",
      description: "Jesus encontra um funeral. O filho único de uma viúva está sendo levado para ser enterrado. Jesus o ressuscita e o entrega à sua mãe.",
      significance: "Mostra compaixão por uma viúva desamparada. Demonstra poder sobre a morte.",
    },
    {
      title: "Cura de um Homem Surdo e Mudo",
      chapter: "11:14",
      type: "Cura de Doença",
      description: "Jesus expulsa um demônio que tornava um homem surdo e mudo. O homem passa a falar.",
      significance: "Mostra que a cura pode vir através da expulsão de demônios. Restaura a capacidade de comunicação.",
    },
    {
      title: "Calmaria da Tempestade",
      chapter: "8:22-25",
      type: "Milagre da Natureza",
      description: "Jesus e seus discípulos estão em um barco quando uma tempestade surge. Jesus repreende o vento e as ondas, e há grande bonança.",
      significance: "Mostra poder sobre a natureza. Ensina sobre fé em tempos de medo.",
    },
    {
      title: "Alimentação dos Cinco Mil",
      chapter: "9:10-17",
      type: "Milagre da Provisão",
      description: "Uma multidão de cinco mil homens (além de mulheres e crianças) segue Jesus. Com apenas cinco pães e dois peixes, Jesus alimenta a todos.",
      significance: "Mostra poder sobre a natureza e provisão divina. Demonstra compaixão pela multidão faminta.",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Milagres de Jesus</h1>
          <p className="text-slate-600 mt-2">
            Demonstrações do poder divino em Lucas
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <Card className="bg-yellow-50 border-yellow-200">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <Zap className="w-8 h-8 text-yellow-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-yellow-900 mb-2">
                    Milagres que Transformaram Vidas
                  </h3>
                  <p className="text-sm text-yellow-800">
                    Lucas relata 20 milagres de Jesus, cada um demonstrando seu poder e compaixão.
                    Esses milagres não eram apenas demonstrações de poder, mas atos de amor e cura.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {miracles.map((miracle, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-xl">{miracle.title}</CardTitle>
                    <p className="text-sm text-slate-500 mt-1">Lucas {miracle.chapter}</p>
                  </div>
                  <Sparkles className="w-6 h-6 text-yellow-500 flex-shrink-0" />
                </div>
                <div className="mt-3">
                  <span className="inline-block px-3 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full font-semibold">
                    {miracle.type}
                  </span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">O que Aconteceu</h4>
                  <p className="text-slate-700">{miracle.description}</p>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Significado</h4>
                  <p className="text-slate-700">{miracle.significance}</p>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const chapterNum = parseInt(miracle.chapter.split(":")[0]);
                    setLocation(`/capitulos/${chapterNum}`);
                  }}
                >
                  Ler Capítulo Completo
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200">
            <CardContent className="pt-8 pb-8">
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                Testemunhe o Poder de Jesus
              </h3>
              <p className="text-slate-600 mb-6">
                Cada milagre revela o amor e o poder de Jesus. Que milagre você precisa em sua vida?
              </p>
              <Button onClick={() => setLocation("/capitulos/1")}>
                Explorar os Capítulos
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
