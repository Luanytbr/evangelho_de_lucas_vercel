import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { BookOpen, Search as SearchIcon } from "lucide-react";
import { useState, useMemo } from "react";

export default function Dictionary() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");

  const terms = [
    {
      term: "Evangelho",
      definition: "Significa 'Boa Nova' ou 'Boas Notícias'. Refere-se à mensagem de salvação através de Jesus Cristo.",
      context: "O Evangelho de Lucas é a narrativa da vida e ensinamentos de Jesus.",
    },
    {
      term: "Parábola",
      definition: "Uma história simples que ensina uma verdade espiritual profunda. Jesus frequentemente usava parábolas para ensinar.",
      context: "Lucas contém muitas parábolas únicas, como a do Bom Samaritano e do Filho Pródigo.",
    },
    {
      term: "Milagre",
      definition: "Um ato sobrenatural que demonstra o poder de Deus. Os milagres de Jesus validam sua autoridade divina.",
      context: "Lucas relata 20 milagres de Jesus, incluindo curas, expulsões de demônios e ressurreições.",
    },
    {
      term: "Apóstolo",
      definition: "Um dos doze discípulos escolhidos por Jesus para ser seus companheiros mais próximos e testemunhas de sua ressurreição.",
      context: "Jesus escolheu doze apóstolos para estar com ele e aprender seus ensinamentos.",
    },
    {
      term: "Discípulo",
      definition: "Um seguidor de Jesus que aprende seus ensinamentos e o segue. Mais amplo que apóstolo.",
      context: "Muitos discípulos seguiram Jesus além dos doze apóstolos.",
    },
    {
      term: "Reino de Deus",
      definition: "O reinado de Deus sobre todas as coisas. Não é um lugar físico, mas o domínio da vontade de Deus.",
      context: "Jesus frequentemente ensina sobre o Reino de Deus e como entrar nele.",
    },
    {
      term: "Arrependimento",
      definition: "Mudança de mente que resulta em mudança de direção. Virar-se de longe de Deus para voltar para Deus.",
      context: "O arrependimento é essencial para a salvação segundo o evangelho de Lucas.",
    },
    {
      term: "Fé",
      definition: "Confiança em Deus e em Jesus Cristo. Crer não apenas intelectualmente, mas confiar completamente.",
      context: "Jesus frequentemente elogia a fé e critica a falta de fé.",
    },
    {
      term: "Graça",
      definition: "O favor imerecido de Deus. A salvação é um presente de Deus, não algo que podemos ganhar.",
      context: "A graça de Deus é central para a mensagem de salvação em Lucas.",
    },
    {
      term: "Salvação",
      definition: "Ser salvo do pecado e suas consequências através da fé em Jesus Cristo.",
      context: "A salvação é oferecida a todos que creem em Jesus, não apenas aos judeus.",
    },
    {
      term: "Pecado",
      definition: "Transgressão da lei de Deus. Qualquer ato, pensamento ou atitude que viola a vontade de Deus.",
      context: "Jesus veio para buscar e salvar os pecadores, não os justos.",
    },
    {
      term: "Redenção",
      definition: "Ser comprado de volta ou libertado. A redenção através de Jesus nos liberta do pecado.",
      context: "A morte de Jesus na cruz é o preço da nossa redenção.",
    },
    {
      term: "Ressurreição",
      definition: "Voltar à vida após a morte. Jesus ressuscitou no terceiro dia após sua crucificação.",
      context: "A ressurreição de Jesus é a base da fé cristã e da esperança de vida eterna.",
    },
    {
      term: "Espírito Santo",
      definition: "A terceira pessoa da Trindade. O Espírito de Deus que habita nos crentes e os guia.",
      context: "O Espírito Santo é enfatizado especialmente em Lucas como o poder de Deus.",
    },
    {
      term: "Trindade",
      definition: "A doutrina de que Deus existe como três pessoas em uma: Pai, Filho e Espírito Santo.",
      context: "A Trindade é implícita em Lucas, particularmente no batismo de Jesus.",
    },
    {
      term: "Encarnação",
      definition: "Deus se tornando carne em Jesus Cristo. O Filho de Deus assumindo forma humana.",
      context: "Lucas enfatiza a humanidade de Jesus enquanto mantém sua divindade.",
    },
    {
      term: "Crucificação",
      definition: "O método romano de execução no qual Jesus foi condenado à morte na cruz.",
      context: "A crucificação de Jesus é o evento central do evangelho.",
    },
    {
      term: "Ascensão",
      definition: "A subida de Jesus ao céu após sua ressurreição.",
      context: "Lucas termina seu evangelho com a ascensão de Jesus ao céu.",
    },
    {
      term: "Batismo",
      definition: "Um ritual de imersão em água que simboliza arrependimento e fé em Jesus.",
      context: "Jesus foi batizado por João Batista, marcando o início de seu ministério público.",
    },
    {
      term: "Comunhão",
      definition: "Também chamada de Ceia do Senhor ou Eucaristia. Celebração da morte de Jesus com pão e vinho.",
      context: "Jesus instituiu a Comunhão na Última Ceia com seus discípulos.",
    },
    {
      term: "Demônio",
      definition: "Um ser espiritual maligno que se opõe a Deus. Também chamado de espírito imundo ou diabo.",
      context: "Jesus frequentemente expulsa demônios como demonstração de seu poder.",
    },
    {
      term: "Publicano",
      definition: "Um coletor de impostos judeu que trabalhava para os romanos. Frequentemente desprezado pelos judeus.",
      context: "Jesus come com publicanos e pecadores, mostrando compaixão pelos marginalizados.",
    },
    {
      term: "Fariseu",
      definition: "Um membro de uma seita judaica que enfatizava a observância rigorosa da lei.",
      context: "Os fariseus frequentemente entram em conflito com Jesus sobre a interpretação da lei.",
    },
    {
      term: "Saduceu",
      definition: "Um membro da elite judaica que negava a ressurreição e os espíritos.",
      context: "Os saduceus questionam Jesus sobre a ressurreição.",
    },
    {
      term: "Sinagoga",
      definition: "Um lugar de adoração e estudo da lei entre os judeus.",
      context: "Jesus frequentemente ensina nas sinagogas durante seu ministério.",
    },
  ];

  const filteredTerms = useMemo(() => {
    if (!searchTerm) return terms;
    return terms.filter(
      (item) =>
        item.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.definition.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm]);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Dicionário Bíblico</h1>
          <p className="text-slate-600 mt-2">
            Termos e conceitos importantes do Evangelho de Lucas
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <Card className="bg-green-50 border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <BookOpen className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-green-900 mb-2">
                    Entenda os Termos Bíblicos
                  </h3>
                  <p className="text-sm text-green-800">
                    Este dicionário contém termos e conceitos importantes para compreender o Evangelho de Lucas.
                    Use a busca abaixo para encontrar rapidamente o termo que procura.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <div className="mb-8">
          <div className="relative">
            <SearchIcon className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar termo..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border rounded-lg text-sm"
            />
          </div>
          <p className="text-sm text-slate-600 mt-2">
            {filteredTerms.length} termo(s) encontrado(s)
          </p>
        </div>

        {/* Terms */}
        <div className="space-y-4">
          {filteredTerms.length > 0 ? (
            filteredTerms.map((item, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg text-green-700">
                    {item.term}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <p className="text-slate-700 font-semibold mb-1">Definição:</p>
                    <p className="text-slate-700">{item.definition}</p>
                  </div>
                  <div className="bg-green-50 p-3 rounded-lg border-l-4 border-green-600">
                    <p className="text-sm text-slate-700">
                      <span className="font-semibold">Contexto em Lucas:</span> {item.context}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-slate-600">
                  Nenhum termo encontrado para "{searchTerm}".
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="pt-8 pb-8">
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                Aprofunde Seu Conhecimento
              </h3>
              <p className="text-slate-600 mb-6">
                Use este dicionário como referência enquanto estuda o Evangelho de Lucas.
              </p>
              <Button onClick={() => setLocation("/capitulos/1")}>
                Começar a Ler
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
