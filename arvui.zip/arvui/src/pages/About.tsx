import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { BookOpen, Heart, MessageSquare, Users } from "lucide-react";

export default function About() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Sobre Este Projeto</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12 max-w-3xl">
        {/* Introdução */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Evangelho de Lucas - Estudo Completo NVI</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-slate-700">
            <p>
              Este é um projeto dedicado a fornecer uma análise completa e acessível do Evangelho de Lucas na tradução NVI (Nova Versão Internacional). Nosso objetivo é facilitar o estudo e a compreensão das escrituras através de uma plataforma interativa e bem estruturada.
            </p>
            <p>
              O Evangelho de Lucas é conhecido por sua ênfase na humanidade de Jesus e sua compaixão pelos marginalizados da sociedade. Lucas, sendo médico e historiador, abordou sua tarefa com rigor científico, investigando cuidadosamente os eventos da vida de Jesus.
            </p>
          </CardContent>
        </Card>

        {/* Sobre Lucas */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Quem foi Lucas?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-slate-700">
            <p>
              Lucas foi um médico grego que acompanhou o apóstolo Paulo em suas jornadas missionárias. Ele é o único evangelista que não era apóstolo, mas sua proximidade com os apóstolos e testemunhas oculares dos eventos lhe permitiu escrever um relato confiável.
            </p>
            <p>
              Lucas escreveu seu evangelho para um cristão grego chamado Teófilo, com o objetivo de fortalecer sua fé através de um relato ordenado e investigado cuidadosamente. Seu evangelho é o mais longo dos quatro evangelhos e inclui histórias e parábolas únicas, como a do Bom Samaritano e a do Filho Pródigo.
            </p>
            <p>
              Características únicas do Evangelho de Lucas incluem sua ênfase na oração, no Espírito Santo, na alegria, na paz e na importância das mulheres na história de Jesus.
            </p>
          </CardContent>
        </Card>

        {/* Características do Site */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Recursos Disponíveis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-blue-600" />
                  <span className="font-semibold">24 Capítulos Completos</span>
                </div>
                <p className="text-sm text-slate-600">
                  Acesso a todos os 24 capítulos do Evangelho de Lucas com contexto histórico
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-green-600" />
                  <span className="font-semibold">Comentários Versículo por Versículo</span>
                </div>
                <p className="text-sm text-slate-600">
                  Explicações detalhadas de cada versículo para melhor compreensão
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Heart className="w-5 h-5 text-red-600" />
                  <span className="font-semibold">Sistema de Marcadores</span>
                </div>
                <p className="text-sm text-slate-600">
                  Salve seus versículos favoritos e acesse-os facilmente depois
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-purple-600" />
                  <span className="font-semibold">Notas Pessoais</span>
                </div>
                <p className="text-sm text-slate-600">
                  Adicione suas próprias reflexões e notas em qualquer versículo
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Estrutura do Evangelho */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Estrutura do Evangelho</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-slate-700">
            <div>
              <h4 className="font-semibold mb-2">Prólogo (Capítulo 1)</h4>
              <p className="text-sm">
                Lucas apresenta seu evangelho e narra o anúncio do nascimento de João Batista e Jesus
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Infância e Preparação (Capítulos 2-3)</h4>
              <p className="text-sm">
                Narrativas do nascimento de Jesus, sua infância e o ministério preparatório de João Batista
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Ministério na Galiléia (Capítulos 4-9)</h4>
              <p className="text-sm">
                Jesus realiza milagres, ensina através de parábolas e escolhe seus apóstolos
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Jornada para Jerusalém (Capítulos 10-18)</h4>
              <p className="text-sm">
                Jesus viaja para Jerusalém, ensinando sobre o Reino de Deus e realizando mais milagres
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Paixão e Ressurreição (Capítulos 19-24)</h4>
              <p className="text-sm">
                Os eventos finais da vida de Jesus, sua morte, ressurreição e ascensão
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Temas Principais */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Temas Principais</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-slate-700">
            <div className="flex gap-3">
              <span className="text-blue-600 font-bold">•</span>
              <div>
                <span className="font-semibold">Humanidade de Jesus:</span> Lucas enfatiza Jesus como o Homem Perfeito, mostrando sua compaixão e identificação com os necessitados
              </div>
            </div>

            <div className="flex gap-3">
              <span className="text-blue-600 font-bold">•</span>
              <div>
                <span className="font-semibold">Inclusão Social:</span> Destaque especial para mulheres, publicanos, pecadores e marginalizados
              </div>
            </div>

            <div className="flex gap-3">
              <span className="text-blue-600 font-bold">•</span>
              <div>
                <span className="font-semibold">Oração e Espírito Santo:</span> Ênfase na importância da oração e do papel do Espírito Santo
              </div>
            </div>

            <div className="flex gap-3">
              <span className="text-blue-600 font-bold">•</span>
              <div>
                <span className="font-semibold">Alegria e Paz:</span> Mensagens de esperança, alegria e paz em Cristo
              </div>
            </div>

            <div className="flex gap-3">
              <span className="text-blue-600 font-bold">•</span>
              <div>
                <span className="font-semibold">Salvação Universal:</span> A salvação é oferecida a todos, não apenas aos judeus
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Como Usar Este Site */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Como Usar Este Site</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-slate-700">
            <div>
              <h4 className="font-semibold mb-1">1. Explorar Capítulos</h4>
              <p className="text-sm">
                Clique em qualquer capítulo na página inicial para ler o texto completo com comentários
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-1">2. Usar a Busca Avançada</h4>
              <p className="text-sm">
                Procure por palavras-chave ou temas específicos para encontrar versículos relevantes
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-1">3. Marcar Favoritos</h4>
              <p className="text-sm">
                Clique no ícone de coração para salvar seus versículos favoritos (requer login)
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-1">4. Adicionar Notas</h4>
              <p className="text-sm">
                Adicione suas próprias reflexões e notas em qualquer versículo
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-1">5. Acompanhar Progresso</h4>
              <p className="text-sm">
                Acesse a página de estatísticas para ver seu progresso de leitura
              </p>
            </div>
          </CardContent>
        </Card>

        {/* CTA */}
        <div className="text-center">
          <Button
            size="lg"
            onClick={() => setLocation("/")}
          >
            Voltar para Home
          </Button>
        </div>
      </div>
    </div>
  );
}
