import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Users, Crown } from "lucide-react";

export default function Characters() {
  const [, setLocation] = useLocation();

  const characters = [
    {
      name: "Jesus Cristo",
      role: "O Protagonista",
      description: "Jesus é o centro do Evangelho de Lucas. Lucas o apresenta como o Homem Perfeito, totalmente humano e compassivo.",
      significance: "Jesus é o Filho de Deus que veio para buscar e salvar os perdidos. Seus ensinamentos, milagres e sacrifício formam a base do evangelho.",
      keyVerses: "Lucas 19:10 - 'Porque o Filho do homem veio buscar e salvar o que se havia perdido'",
    },
    {
      name: "Maria",
      role: "Mãe de Jesus",
      description: "Maria é apresentada de forma mais detalhada em Lucas do que em qualquer outro evangelho. Lucas enfatiza sua fé, obediência e reflexão.",
      significance: "Maria é um modelo de fé e submissão à vontade de Deus. Ela guarda as palavras de Jesus em seu coração e as medita.",
      keyVerses: "Lucas 1:46-55 - O Magnificat, o cântico de louvor de Maria",
    },
    {
      name: "João Batista",
      role: "Precursor de Jesus",
      description: "João Batista é o profeta que prepara o caminho para Jesus. Lucas fornece detalhes únicos sobre seu nascimento e ministério.",
      significance: "João batiza Jesus e testemunha que ele é o Cordeiro de Deus. Sua morte marca o fim da era do Antigo Testamento.",
      keyVerses: "Lucas 3:16 - 'Eu vos batizo com água; mas vem aquele que é mais poderoso do que eu'",
    },
    {
      name: "Simão Pedro",
      role: "Apóstolo Líder",
      description: "Pedro é um dos primeiros discípulos chamados por Jesus. Ele é impetuoso, leal e eventualmente se torna um líder da igreja.",
      significance: "Pedro é a rocha sobre a qual Jesus construirá sua igreja. Apesar de seus fracassos, ele é restaurado e se torna um apóstolo poderoso.",
      keyVerses: "Lucas 5:8 - 'Afasta-te de mim, Senhor, porque sou um homem pecador'",
    },
    {
      name: "Tiago e João",
      role: "Apóstolos Filhos do Trovão",
      description: "Irmãos que são chamados para serem discípulos de Jesus. Eles estão entre os apóstolos mais próximos de Jesus.",
      significance: "Tiago e João testemunham eventos importantes como a ressurreição da filha de Jairo e a transfiguração. João se torna um dos líderes da igreja.",
      keyVerses: "Lucas 9:54 - 'Senhor, queres que digamos que desça fogo do céu e os consuma?'",
    },
    {
      name: "Zaqueu",
      role: "Publicano Arrependido",
      description: "Um publicano rico que é transformado pelo encontro com Jesus. Ele era desonesto em seus negócios, mas se arrepende.",
      significance: "A história de Zaqueu mostra que ninguém é tão perdido que não possa ser salvo. Jesus vem para sua casa e traz salvação.",
      keyVerses: "Lucas 19:8 - 'Senhor, eis que dou a metade dos meus bens aos pobres'",
    },
    {
      name: "A Mulher Pecadora",
      role: "Pecadora Arrependida",
      description: "Uma mulher com reputação de pecadora unge os pés de Jesus com perfume e os enxuga com seus cabelos.",
      significance: "Ela representa o arrependimento genuíno e a fé. Jesus a perdoa e a envia em paz, dizendo que sua fé a salvou.",
      keyVerses: "Lucas 7:47 - 'Portanto, te digo que os seus muitos pecados lhe são perdoados'",
    },
    {
      name: "Jairo",
      role: "Líder da Sinagoga",
      description: "Um líder da sinagoga que pede a Jesus para curar sua filha que está morrendo.",
      significance: "Jairo representa a fé diante da morte. Apesar da morte de sua filha ser anunciada, Jesus a ressuscita.",
      keyVerses: "Lucas 8:42 - 'Porque tinha uma filha única, de uns doze anos, que estava morrendo'",
    },
    {
      name: "A Viúva de Naim",
      role: "Mãe Enlutada",
      description: "Uma viúva cujo filho único está sendo levado para ser enterrado. Jesus encontra o funeral e ressuscita o rapaz.",
      significance: "Ela representa a compaixão de Jesus pelos enlutados e desamparados. Jesus se compadece dela e restaura seu filho.",
      keyVerses: "Lucas 7:13 - 'E, vendo-a, o Senhor se compadeceu dela'",
    },
    {
      name: "Herodes Antipas",
      role: "Tetrarca de Galiléia",
      description: "Governante que mata João Batista e quer ver Jesus. Ele é movido pela curiosidade, não pela fé.",
      significance: "Herodes representa o poder político que rejeita Jesus. Ele é um antagonista que contribui para a morte de João Batista.",
      keyVerses: "Lucas 9:9 - 'Herodes disse: Eu mandei degolar João; quem é este de quem ouço tais coisas?'",
    },
    {
      name: "Pôncio Pilatos",
      role: "Governador Romano",
      description: "O governador romano que julga Jesus e o entrega para ser crucificado, apesar de reconhecer sua inocência.",
      significance: "Pilatos representa a fraqueza e a covardia diante da pressão. Ele lava as mãos, mas não pode escapar da responsabilidade.",
      keyVerses: "Lucas 23:4 - 'Então Pilatos disse aos principais sacerdotes e à multidão: Nenhuma culpa acho neste homem'",
    },
    {
      name: "O Ladrão Arrependido",
      role: "Criminoso Redimido",
      description: "Um dos dois ladrões crucificados com Jesus que se arrepende e pede a Jesus que se lembre dele.",
      significance: "Ele representa a salvação de última hora. Jesus promete que ele estará com ele no paraíso naquele mesmo dia.",
      keyVerses: "Lucas 23:43 - 'Hoje estarás comigo no paraíso'",
    },
    {
      name: "Maria Madalena",
      role: "Seguidora de Jesus",
      description: "Uma mulher que é libertada de sete demônios por Jesus. Ela se torna uma seguidora leal e é a primeira a ver o Jesus ressuscitado.",
      significance: "Maria Madalena representa a redenção e a fidelidade. Ela é testemunha da ressurreição e anunciadora da Boa Nova.",
      keyVerses: "Lucas 8:2 - 'E também algumas mulheres que tinham sido curadas de espíritos malignos'",
    },
    {
      name: "Zacarias",
      role: "Sacerdote Pai de João Batista",
      description: "Um sacerdote que recebe a promessa de que terá um filho apesar de sua idade avançada. Ele é mudo por não crer.",
      significance: "Zacarias representa a fé que vence a incredulidade. Quando seu filho nasce, ele recupera a fala e profetiza.",
      keyVerses: "Lucas 1:67 - 'E Zacarias, seu pai, foi cheio do Espírito Santo'",
    },
    {
      name: "Isabel",
      role: "Mãe de João Batista",
      description: "Esposa de Zacarias que concebe João Batista em sua idade avançada. Ela é descrita como justa e temente a Deus.",
      significance: "Isabel representa a fé e a obediência. Ela é abençoada com um filho que será grande diante do Senhor.",
      keyVerses: "Lucas 1:42 - 'Bendita és tu entre as mulheres'",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Personagens Principais</h1>
          <p className="text-slate-600 mt-2">
            Conheça os personagens importantes do Evangelho de Lucas
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <Card className="bg-indigo-50 border-indigo-200">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <Users className="w-8 h-8 text-indigo-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-indigo-900 mb-2">
                    Personagens que Moldaram a História
                  </h3>
                  <p className="text-sm text-indigo-800">
                    Cada personagem em Lucas tem um papel importante na história da salvação.
                    Conheça suas histórias, suas lutas e suas transformações.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {characters.map((character, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-xl">{character.name}</CardTitle>
                    <p className="text-sm text-slate-500 mt-1 font-semibold text-indigo-600">
                      {character.role}
                    </p>
                  </div>
                  <Crown className="w-6 h-6 text-indigo-600 flex-shrink-0" />
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Quem é?</h4>
                  <p className="text-slate-700">{character.description}</p>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Significado</h4>
                  <p className="text-slate-700">{character.significance}</p>
                </div>

                <div className="bg-indigo-50 p-4 rounded-lg border-l-4 border-indigo-600">
                  <p className="text-sm text-slate-700">
                    <span className="font-semibold">Versículo-chave:</span> {character.keyVerses}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Card className="bg-gradient-to-r from-indigo-50 to-blue-50 border-indigo-200">
            <CardContent className="pt-8 pb-8">
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                Descubra Mais sobre Esses Personagens
              </h3>
              <p className="text-slate-600 mb-6">
                Leia os capítulos completos para entender melhor as histórias e transformações desses personagens.
              </p>
              <Button onClick={() => setLocation("/capitulos/1")}>
                Explorar os Capítulos
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
