import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { BookOpen, Heart, MessageSquare, Search, Lightbulb, BookMarked, Sparkles, Users, Brain } from "lucide-react";
import { useLocation } from "wouter";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { data: chapters, isLoading: chaptersLoading } = trpc.chapters.list.useQuery();

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      {/* Header */}
      <header className="border-b bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BookOpen className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-slate-900">{APP_TITLE}</h1>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <span className="text-sm text-slate-600">{user?.name}</span>
                <Button
                  onClick={() => setLocation("/estatisticas")}
                  variant="ghost"
                  size="sm"
                >
                  Estatísticas
                </Button>
                <Button
                  onClick={() => logout()}
                  variant="outline"
                  size="sm"
                >
                  Sair
                </Button>
              </>
            ) : (
              <Button
                onClick={() => (window.location.href = getLoginUrl())}
                size="sm"
              >
                Entrar
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Evangelho de Lucas</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Estudo completo do Evangelho de Lucas na tradução NVI com explicações detalhadas, contexto histórico e comentários versículo por versículo.
          </p>
          <div className="flex gap-4 justify-center">
            <Button
              size="lg"
              variant="secondary"
              onClick={() => setLocation("/capitulos/1")}
            >
              Começar Leitura
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-blue-700"
              onClick={() => setLocation("/sobre")}
            >
              Sobre Lucas
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center mb-12">Recursos Disponíveis</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader>
                <BookOpen className="w-8 h-8 text-blue-600 mb-2" />
                <CardTitle>24 Capítulos</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">
                  Todos os capítulos do Evangelho de Lucas na tradução NVI
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <MessageSquare className="w-8 h-8 text-green-600 mb-2" />
                <CardTitle>Comentários</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">
                  Explicações detalhadas versículo por versículo
                </p>
              </CardContent>
            </Card>

            <Card
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setLocation("/busca")}
            >
              <CardHeader>
                <Search className="w-8 h-8 text-purple-600 mb-2" />
                <CardTitle>Busca Avançada</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">
                  Encontre versículos por tema ou palavra-chave
                </p>
              </CardContent>
            </Card>

            <Card
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setLocation("/marcadores")}
            >
              <CardHeader>
                <Heart className="w-8 h-8 text-red-600 mb-2" />
                <CardTitle>Marcadores</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">
                  Salve seus versículos favoritos e notas pessoais
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Chapters Preview */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold mb-12">Capítulos Disponíveis</h3>
          {chaptersLoading ? (
            <div className="text-center py-8">
              <p className="text-slate-600">Carregando capítulos...</p>
            </div>
          ) : chapters && chapters.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {chapters.map((chapter) => (
                <Card
                  key={chapter.id}
                  className="cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => setLocation(`/capitulos/${chapter.chapterNumber}`)}
                >
                  <CardHeader>
                    <CardTitle className="text-lg">
                      Capítulo {chapter.chapterNumber}
                    </CardTitle>
                    <CardDescription>{chapter.title}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-slate-600 line-clamp-3">
                      {chapter.context}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-slate-600">Nenhum capítulo disponível no momento.</p>
            </div>
          )}
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-slate-50">
        <div className="container mx-auto px-4 max-w-3xl">
          <h3 className="text-3xl font-bold mb-6">Sobre o Evangelho de Lucas</h3>
          <div className="space-y-4 text-slate-700">
            <p>
              Lucas é o terceiro evangelho do Novo Testamento e é o único evangelho escrito por um não-apóstolo. Lucas era um médico grego que acompanhou o apóstolo Paulo em suas jornadas missionárias.
            </p>
            <p>
              Diferente dos outros evangelistas, Lucas apresenta Jesus como o Homem Perfeito, enfatizando sua humanidade e compaixão pelos marginalizados da sociedade. Seu evangelho é conhecido por incluir histórias e parábolas únicas, como a do Bom Samaritano e a do Filho Pródigo.
            </p>
            <p>
              Lucas escreveu seu evangelho para um cristão grego chamado Teófilo, com o objetivo de fortalecer sua fé através de um relato ordenado e investigado cuidadosamente dos eventos da vida de Jesus, desde seu nascimento até sua ascensão.
            </p>
            <p>
              Este site oferece uma análise completa de todos os 24 capítulos de Lucas na tradução NVI, incluindo contexto histórico, explicações versículo por versículo e comentários que ajudam a compreender melhor a mensagem do evangelho.
            </p>
          </div>
        </div>
      </section>

      {/* Educational Resources Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center mb-12">Recursos Educacionais</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setLocation("/curiosidades")}
            >
              <CardHeader>
                <Lightbulb className="w-8 h-8 text-amber-600 mb-2" />
                <CardTitle>Curiosidades</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">
                  Fatos interessantes sobre Lucas e seus ensinamentos
                </p>
              </CardContent>
            </Card>

            <Card
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setLocation("/parabolas")}
            >
              <CardHeader>
                <BookMarked className="w-8 h-8 text-indigo-600 mb-2" />
                <CardTitle>Parábolas</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">
                  Histórias com significado profundo ensinadas por Jesus
                </p>
              </CardContent>
            </Card>

            <Card
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setLocation("/milagres")}
            >
              <CardHeader>
                <Sparkles className="w-8 h-8 text-yellow-600 mb-2" />
                <CardTitle>Milagres</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">
                  Demonstrações do poder divino de Jesus
                </p>
              </CardContent>
            </Card>

            <Card
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setLocation("/personagens")}
            >
              <CardHeader>
                <Users className="w-8 h-8 text-purple-600 mb-2" />
                <CardTitle>Personagens</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">
                  Conheça os personagens principais e suas histórias
                </p>
              </CardContent>
            </Card>

            <Card
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setLocation("/dicionario")}
            >
              <CardHeader>
                <BookOpen className="w-8 h-8 text-green-600 mb-2" />
                <CardTitle>Dicionário</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">
                  Termos e conceitos bíblicos importantes
                </p>
              </CardContent>
            </Card>

            <Card
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setLocation("/quiz")}
            >
              <CardHeader>
                <Brain className="w-8 h-8 text-red-600 mb-2" />
                <CardTitle>Quiz</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">
                  Teste seus conhecimentos sobre Lucas
                </p>
              </CardContent>
            </Card>

            <Card
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setLocation("/teologia")}
            >
              <CardHeader>
                <BookOpen className="w-8 h-8 text-indigo-600 mb-2" />
                <CardTitle>Teologia</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">
                  Estudos teológicos profundos sobre as doutrinas cristãs
                </p>
              </CardContent>
            </Card>

            <Card
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setLocation("/meditacoes")}
            >
              <CardHeader>
                <Heart className="w-8 h-8 text-rose-600 mb-2" />
                <CardTitle>Meditações</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">
                  Versículos para refletir e transformar sua vida
                </p>
              </CardContent>
            </Card>

            <Card
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setLocation("/aplicacao")}
            >
              <CardHeader>
                <Lightbulb className="w-8 h-8 text-green-600 mb-2" />
                <CardTitle>Aplicação Prática</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">
                  Como aplicar os ensinamentos de Jesus na vida moderna
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="font-semibold mb-4">Navegação</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li>
                  <button onClick={() => setLocation("/")} className="hover:text-white transition">
                    Home
                  </button>
                </li>
                <li>
                  <button onClick={() => setLocation("/busca")} className="hover:text-white transition">
                    Busca
                  </button>
                </li>
                <li>
                  <button onClick={() => setLocation("/sobre")} className="hover:text-white transition">
                    Sobre
                  </button>
                </li>
                <li>
                  <button onClick={() => setLocation("/curiosidades")} className="hover:text-white transition">
                    Curiosidades
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Recursos</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li>
                  <button onClick={() => setLocation("/parabolas")} className="hover:text-white transition">
                    Parábolas
                  </button>
                </li>
                <li>
                  <button onClick={() => setLocation("/milagres")} className="hover:text-white transition">
                    Milagres
                  </button>
                </li>
                <li>
                  <button onClick={() => setLocation("/personagens")} className="hover:text-white transition">
                    Personagens
                  </button>
                </li>
                <li>
                  <button onClick={() => setLocation("/dicionario")} className="hover:text-white transition">
                    Dicionário
                  </button>
                </li>
                <li>
                  <button onClick={() => setLocation("/quiz")} className="hover:text-white transition">
                    Quiz
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Aprofundamento</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li>
                  <button onClick={() => setLocation("/teologia")} className="hover:text-white transition">
                    Teologia
                  </button>
                </li>
                <li>
                  <button onClick={() => setLocation("/meditacoes")} className="hover:text-white transition">
                    Meditações
                  </button>
                </li>
                <li>
                  <button onClick={() => setLocation("/aplicacao")} className="hover:text-white transition">
                    Aplicação Prática
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Meus Recursos</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li>
                  <button onClick={() => setLocation("/marcadores")} className="hover:text-white transition">
                    Marcadores
                  </button>
                </li>
                <li>
                  <button onClick={() => setLocation("/estatisticas")} className="hover:text-white transition">
                    Estatísticas
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Sobre</h4>
              <p className="text-sm text-slate-400">
                Estudo completo do Evangelho de Lucas na tradução NVI com explicações, curiosidades, parábolas, milagres e muito mais.
              </p>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-8 text-center">
            <p className="text-sm text-slate-400">
              © 2024 Evangelho de Lucas - Estudo Completo NVI. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
