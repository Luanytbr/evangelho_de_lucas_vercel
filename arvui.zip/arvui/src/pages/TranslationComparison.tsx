import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { BookOpen, GitCompare } from "lucide-react";
import { useState } from "react";

export default function TranslationComparison() {
  const [, setLocation] = useLocation();
  const [selectedVerse, setSelectedVerse] = useState<number>(0);

  const verses = [
    {
      reference: "Lucas 1:37",
      nvi: "Porque para Deus nada é impossível.",
      almeida: "Porque para Deus nada é impossível.",
      kingJames: "For with God nothing shall be impossible.",
      note: "Este versículo é praticamente idêntico em todas as traduções. Enfatiza o poder onipotente de Deus.",
    },
    {
      reference: "Lucas 6:31",
      nvi: "Trata os outros da maneira como você gostaria de ser tratado.",
      almeida: "E como quereis que os homens vos façam, assim fazei-lho também vós.",
      kingJames: "And as ye would that men should do to you, do ye also to them likewise.",
      note: "A NVI usa linguagem mais moderna e acessível, enquanto Almeida é mais formal. A essência é a mesma.",
    },
    {
      reference: "Lucas 12:34",
      nvi: "Pois onde está o seu tesouro, aí estará também o seu coração.",
      almeida: "Porque onde está o vosso tesouro, aí estará também o vosso coração.",
      kingJames: "For where your treasure is, there will your heart be also.",
      note: "Todas as traduções capturam bem a ideia central. A diferença está na escolha de palavras.",
    },
    {
      reference: "Lucas 15:10",
      nvi: "Da mesma forma, há alegria diante dos anjos de Deus por um pecador que se arrepende.",
      almeida: "Assim vos digo que há alegria diante dos anjos de Deus por um pecador que se arrepende.",
      kingJames: "Likewise, I say unto you, there is joy in the presence of the angels of God over one sinner that repenteth.",
      note: "A NVI simplifica a estrutura, enquanto King James mantém um tom mais solene e formal.",
    },
    {
      reference: "Lucas 8:15",
      nvi: "Mas a semente no solo bom representa os que ouvem a palavra, a retêm de bom grado e produzem uma colheita pelo perseverar.",
      almeida: "E a que caiu em boa terra são estes que, ouvindo a palavra, a retêm num coração honesto e bom, e dão fruto com perseverança.",
      kingJames: "But that on the good ground are they, which in an honest and good heart, having heard the word, keep it, and bring forth fruit with patience.",
      note: "A NVI é mais concisa. Almeida e King James são mais descritivas. Todas mantêm o significado.",
    },
    {
      reference: "Lucas 11:9",
      nvi: "Portanto, eu vos digo: Peçam, e lhes será dado; busquem, e encontrarão; batam, e a porta lhes será aberta.",
      almeida: "E eu vos digo: Pedi, e dar-se-vos-á; buscai, e achareis; batei, e abrir-se-vos-á.",
      kingJames: "And I say unto you, Ask, and it shall be given you; seek, and ye shall find; knock, and it shall be opened unto you.",
      note: "A estrutura paralela é mantida em todas. A NVI usa imperativo direto, enquanto outras usam formas verbais diferentes.",
    },
    {
      reference: "Lucas 6:45",
      nvi: "O homem bom tira do bom tesouro do seu coração coisas boas; mas o homem mau tira do mau tesouro coisas más.",
      almeida: "O homem bom do bom tesouro do seu coração tira o bem, e o homem mau do mau tesouro tira o mal; porque a boca fala do que está cheio o coração.",
      kingJames: "A good man out of the good treasure of his heart bringeth forth that which is good: and an evil man out of the evil treasure bringeth forth that which is evil: for of the abundance of the heart his mouth speaketh.",
      note: "Almeida e King James adicionam uma frase sobre a boca. A NVI é mais concisa mas mantém o significado central.",
    },
    {
      reference: "Lucas 19:10",
      nvi: "Pois o Filho do homem veio procurar e salvar o que estava perdido.",
      almeida: "Porque o Filho do homem veio procurar e salvar o que se havia perdido.",
      kingJames: "For the Son of man is come to seek and to save that which was lost.",
      note: "Todas as traduções capturam bem a missão de Jesus. Pequenas variações na estrutura gramatical.",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Comparação de Traduções</h1>
          <p className="text-slate-600 mt-2">
            Compare versículos em diferentes traduções bíblicas
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <Card className="bg-purple-50 border-purple-200">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <GitCompare className="w-8 h-8 text-purple-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-purple-900 mb-2">
                    Entenda as Nuances das Traduções
                  </h3>
                  <p className="text-sm text-purple-800">
                    Diferentes traduções bíblicas enfatizam diferentes aspectos do texto original. Comparar traduções
                    ajuda a obter uma compreensão mais profunda do significado. Aqui comparamos NVI, Almeida e King James.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-4 gap-6">
          {/* Verse List */}
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Versículos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {verses.map((verse, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedVerse(index)}
                      className={`w-full text-left p-3 rounded-lg transition-all ${
                        selectedVerse === index
                          ? "bg-purple-600 text-white"
                          : "bg-slate-100 text-slate-900 hover:bg-slate-200"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <BookOpen className="w-4 h-4 flex-shrink-0" />
                        <span className="font-medium text-sm">{verse.reference}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Verse Comparison */}
          <div className="md:col-span-3">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-2xl">
                  {verses[selectedVerse].reference}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* NVI */}
                <div className="border-l-4 border-blue-600 pl-4">
                  <h4 className="font-semibold text-slate-900 mb-2 text-blue-600">
                    Tradução NVI (Nova Versão Internacional)
                  </h4>
                  <p className="text-slate-700 italic">
                    "{verses[selectedVerse].nvi}"
                  </p>
                  <p className="text-xs text-slate-500 mt-2">
                    Tradução moderna, acessível e literal
                  </p>
                </div>

                {/* Almeida */}
                <div className="border-l-4 border-green-600 pl-4">
                  <h4 className="font-semibold text-slate-900 mb-2 text-green-600">
                    Tradução Almeida (Almeida Revista e Corrigida)
                  </h4>
                  <p className="text-slate-700 italic">
                    "{verses[selectedVerse].almeida}"
                  </p>
                  <p className="text-xs text-slate-500 mt-2">
                    Tradução clássica, formal e tradicional
                  </p>
                </div>

                {/* King James */}
                <div className="border-l-4 border-amber-600 pl-4">
                  <h4 className="font-semibold text-slate-900 mb-2 text-amber-600">
                    King James Version (KJV)
                  </h4>
                  <p className="text-slate-700 italic">
                    "{verses[selectedVerse].kingJames}"
                  </p>
                  <p className="text-xs text-slate-500 mt-2">
                    Tradução clássica em inglês, formal e solene
                  </p>
                </div>

                {/* Analysis */}
                <div className="bg-slate-100 p-4 rounded-lg">
                  <h4 className="font-semibold text-slate-900 mb-2">Análise</h4>
                  <p className="text-slate-700">{verses[selectedVerse].note}</p>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const chapterNum = parseInt(verses[selectedVerse].reference.split(":")[0].split(" ")[1]);
                    setLocation(`/capitulos/${chapterNum}`);
                  }}
                >
                  Ler Capítulo Completo
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Translation Guide */}
        <div className="mt-12 grid md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">NVI</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-slate-700">
              <p>
                <span className="font-semibold">Estilo:</span> Moderna e acessível
              </p>
              <p>
                <span className="font-semibold">Abordagem:</span> Literal com ênfase na clareza
              </p>
              <p>
                <span className="font-semibold">Ideal para:</span> Leitura devocional e estudo
              </p>
              <p>
                <span className="font-semibold">Características:</span> Linguagem contemporânea, fácil de entender
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Almeida</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-slate-700">
              <p>
                <span className="font-semibold">Estilo:</span> Clássica e formal
              </p>
              <p>
                <span className="font-semibold">Abordagem:</span> Literal com tom tradicional
              </p>
              <p>
                <span className="font-semibold">Ideal para:</span> Estudo acadêmico e tradição
              </p>
              <p>
                <span className="font-semibold">Características:</span> Linguagem formal, respeitosa
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">King James</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-slate-700">
              <p>
                <span className="font-semibold">Estilo:</span> Clássica em inglês
              </p>
              <p>
                <span className="font-semibold">Abordagem:</span> Literal e formal
              </p>
              <p>
                <span className="font-semibold">Ideal para:</span> Estudo comparativo
              </p>
              <p>
                <span className="font-semibold">Características:</span> Linguagem solene, tradicional
              </p>
            </CardContent>
          </Card>
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
            <CardContent className="pt-8 pb-8">
              <BookOpen className="w-12 h-12 text-purple-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                Aprofunde Seu Estudo Bíblico
              </h3>
              <p className="text-slate-600 mb-6">
                Comparar traduções ajuda a compreender melhor o significado original dos versículos.
              </p>
              <Button onClick={() => setLocation("/capitulos/1")}>
                Explorar os Capítulos
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
