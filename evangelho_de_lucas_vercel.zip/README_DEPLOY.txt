Projeto: Evangelho de Lucas — pronto para deploy na Vercel
-------------------------------------------------------
Conteúdo: este pacote contém os arquivos do front-end extraídos do seu projeto Manus.ai.
Observações importantes:
- A tradução NVI é protegida por direitos autorais. Certifique-se de possuir licença para publicar estes textos.
- Se o projeto original é uma aplicação React/Vite já, os arquivos src/ e package.json devem estar presentes.

Como publicar no Vercel (passos rápidos):
1. Crie uma conta em https://vercel.com (ou faça login).
2. No painel, clique em "New Project" -> "Import" -> selecione "Upload" e arraste este arquivo ZIP.
3. Vercel reconhecerá o projeto como estático. Clique em Deploy.
4. Após deploy, seu site ficará disponível em um domínio do tipo: https://your-project-name.vercel.app

Comandos locais (se tiver Node.js instalado):
  npm install
  npm run dev       # roda em localhost para desenvolvimento
  npm run build     # cria pasta de distribuição (dist/)
  npm run preview   # pré-visualizar o build localmente

Para me avisar: depois que fizer o deploy, me envie o link público e eu faço ajustes finais (mapas, quizzes, export PDF, etc.).
