import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import ChapterView from "./pages/ChapterView";
import Search from "./pages/Search";
import Bookmarks from "./pages/Bookmarks";
import Statistics from "./pages/Statistics";
import About from "./pages/About";
import Curiosities from "./pages/Curiosities";
import Parables from "./pages/Parables";
import Miracles from "./pages/Miracles";
import Characters from "./pages/Characters";
import Dictionary from "./pages/Dictionary";
import Quiz from "./pages/Quiz";
import Theology from "./pages/Theology";
import Meditations from "./pages/Meditations";
import PracticalApplication from "./pages/PracticalApplication";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/capitulos/:chapterNumber"} component={ChapterView} />
      <Route path={"/busca"} component={Search} />
      <Route path={"/marcadores"} component={Bookmarks} />
      <Route path={"/estatisticas"} component={Statistics} />
      <Route path={"/sobre"} component={About} />
      <Route path={"/curiosidades"} component={Curiosities} />
      <Route path={"/parabolas"} component={Parables} />
      <Route path={"/milagres"} component={Miracles} />
      <Route path={"/personagens"} component={Characters} />
      <Route path={"/dicionario"} component={Dictionary} />
      <Route path={"/quiz"} component={Quiz} />
      <Route path={"/teologia"} component={Theology} />
      <Route path={"/meditacoes"} component={Meditations} />
      <Route path={"/aplicacao"} component={PracticalApplication} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
