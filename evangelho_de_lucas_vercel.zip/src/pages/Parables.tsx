import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { BookMarked, MessageCircle } from "lucide-react";

export default function Parables() {
  const [, setLocation] = useLocation();

  const parables = [
    {
      title: "O Semeador",
      chapter: "8:4-15",
      summary: "Jesus ensina sobre diferentes tipos de solos que recebem a Palavra de Deus.",
      meaning: "A Palavra de Deus é semeada em diferentes corações. O resultado depende de como as pessoas recebem e guardam a palavra.",
      lesson: "Devemos ser solo fértil para a Palavra de Deus, removendo as pedras e espinhos que impedem o crescimento espiritual.",
    },
    {
      title: "O Bom Samaritano",
      chapter: "10:25-37",
      summary: "Um samaritano ajuda um judeu ferido à beira da estrada, enquanto um sacerdote e levita passam direto.",
      meaning: "Verdadeiro amor ao próximo transcende barreiras culturais, religiosas e sociais.",
      lesson: "Devemos amar nossos inimigos e ajudar qualquer pessoa necessitada, independentemente de sua origem ou religião.",
    },
    {
      title: "O Filho Pródigo",
      chapter: "15:11-32",
      summary: "Um pai amoroso recebe de volta seu filho que havia desperdiçado toda sua herança.",
      meaning: "Deus é um pai amoroso que sempre está pronto para perdoar e receber de volta aqueles que se arrependem.",
      lesson: "Não importa quão longe você tenha ido, Deus sempre o ama e está pronto para perdoá-lo quando você se arrepender.",
    },
    {
      title: "O Publicano e o Fariseu",
      chapter: "18:9-14",
      summary: "Um fariseu se gaba de sua justiça, enquanto um publicano pede perdão a Deus humildemente.",
      meaning: "A humildade e o arrependimento são mais valiosos que a auto-justiça e o orgulho.",
      lesson: "Devemos ser humildes diante de Deus e reconhecer nossa necessidade de Sua graça, não confiando em nossas próprias obras.",
    },
    {
      title: "A Ovelha Perdida",
      chapter: "15:3-7",
      summary: "Um pastor deixa 99 ovelhas para procurar a uma que se perdeu.",
      meaning: "Cada pessoa é valiosa para Deus. Ele se alegra quando uma pessoa perdida é encontrada e se arrepende.",
      lesson: "Devemos valorizar cada pessoa e estar dispostos a fazer esforços para ajudar aqueles que estão perdidos ou afastados de Deus.",
    },
    {
      title: "A Moeda Perdida",
      chapter: "15:8-10",
      summary: "Uma mulher procura diligentemente uma moeda perdida e se alegra quando a encontra.",
      meaning: "O arrependimento de um pecador traz alegria no céu. Deus se alegra com o retorno de cada pessoa.",
      lesson: "Assim como a mulher se alegra ao encontrar a moeda, Deus se alegra com o arrependimento de cada pessoa.",
    },
    {
      title: "O Administrador Infiel",
      chapter: "16:1-13",
      summary: "Um administrador desonesto é descoberto e usa sua posição para se beneficiar antes de ser demitido.",
      meaning: "Devemos ser sábios e prudentes no uso dos recursos que Deus nos confiou.",
      lesson: "Não podemos servir a dois senhores. Devemos escolher entre servir a Deus ou ao dinheiro.",
    },
    {
      title: "O Homem Rico e Lázaro",
      chapter: "16:19-31",
      summary: "Um homem rico ignora um mendigo pobre à sua porta. Após a morte, seus papéis se invertem.",
      meaning: "A riqueza material não garante felicidade eterna. Devemos ser compassivos com os pobres e necessitados.",
      lesson: "Devemos usar nossas riquezas para ajudar os necessitados, pois a eternidade é mais importante que a riqueza temporal.",
    },
    {
      title: "Os Dez Leprosos",
      chapter: "17:11-19",
      summary: "Jesus cura dez leprosos, mas apenas um volta para agradecer.",
      meaning: "A gratidão é importante. Devemos sempre agradecer a Deus pelas bênçãos que recebemos.",
      lesson: "Devemos ser gratos a Deus e reconhecer Suas bênçãos em nossas vidas, não apenas pedir ajuda.",
    },
    {
      title: "A Viúva Persistente",
      chapter: "18:1-8",
      summary: "Uma viúva persistentemente pede justiça a um juiz injusto até que ele a atende.",
      meaning: "Devemos ser persistentes em nossas orações e nunca desistir de pedir a Deus.",
      lesson: "A oração persistente é poderosa. Devemos continuar orando e confiando em Deus, mesmo quando as respostas não vêm imediatamente.",
    },
    {
      title: "O Farol e a Lâmpada",
      chapter: "8:16-18",
      summary: "Uma lâmpada é acesa para iluminar, não para ser escondida.",
      meaning: "A fé em Jesus deve ser visível e influenciar outros, não deve ser escondida.",
      lesson: "Devemos deixar nossa luz brilhar e ser sal e luz para o mundo ao nosso redor.",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Parábolas de Jesus</h1>
          <p className="text-slate-600 mt-2">
            Histórias com significado profundo ensinadas por Jesus em Lucas
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <Card className="bg-purple-50 border-purple-200">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <MessageCircle className="w-8 h-8 text-purple-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-purple-900 mb-2">
                    Entenda as Parábolas
                  </h3>
                  <p className="text-sm text-purple-800">
                    As parábolas são histórias que Jesus contava para ensinar verdades espirituais profundas.
                    Cada parábola tem um significado e uma lição importante para nossas vidas.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {parables.map((parable, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-xl">{parable.title}</CardTitle>
                    <p className="text-sm text-slate-500 mt-1">Lucas {parable.chapter}</p>
                  </div>
                  <BookMarked className="w-6 h-6 text-purple-600 flex-shrink-0" />
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Resumo</h4>
                  <p className="text-slate-700">{parable.summary}</p>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Significado</h4>
                  <p className="text-slate-700">{parable.meaning}</p>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Lição para Nossas Vidas</h4>
                  <p className="text-slate-700">{parable.lesson}</p>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const chapterNum = parseInt(parable.chapter.split(":")[0]);
                    setLocation(`/capitulos/${chapterNum}`);
                  }}
                >
                  Ler Capítulo Completo
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
            <CardContent className="pt-8 pb-8">
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                Reflita sobre as Parábolas
              </h3>
              <p className="text-slate-600 mb-6">
                Cada parábola contém lições profundas. Dedique tempo para refletir sobre como elas se aplicam à sua vida.
              </p>
              <Button onClick={() => setLocation("/capitulos/1")}>
                Explorar os Capítulos
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
