import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Heart, LogIn } from "lucide-react";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";

export default function Bookmarks() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  const { data: bookmarks, isLoading } = trpc.bookmarks.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: chapters } = trpc.chapters.list.useQuery();
  const removeBookmarkMutation = trpc.bookmarks.remove.useMutation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-50">
        <header className="bg-white border-b shadow-sm">
          <div className="container mx-auto px-4 py-4">
            <Button
              variant="ghost"
              onClick={() => setLocation("/")}
              className="mb-4"
            >
              ← Voltar
            </Button>
            <h1 className="text-3xl font-bold text-slate-900">Meus Marcadores</h1>
          </div>
        </header>

        <div className="container mx-auto px-4 py-12">
          <Card className="max-w-md mx-auto">
            <CardContent className="py-12 text-center">
              <LogIn className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-600 mb-4">
                Você precisa estar autenticado para acessar seus marcadores.
              </p>
              <Button
                onClick={() => (window.location.href = getLoginUrl())}
              >
                Fazer Login
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Meus Marcadores</h1>
          <p className="text-slate-600 mt-2">
            Seus versículos favoritos salvos
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {isLoading ? (
          <div className="text-center py-8">
            <p className="text-slate-600">Carregando marcadores...</p>
          </div>
        ) : bookmarks && bookmarks.length > 0 ? (
          <div className="space-y-4">
            {bookmarks.map((bookmark) => {
              const chapter = chapters?.find((ch: any) => ch.id === (bookmark as any).verseId);

              if (!chapter) return null;

              return (
                <Card key={bookmark.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-base">
                          Marcador salvo
                        </CardTitle>
                        <p className="text-sm text-slate-600 mt-1">
                          Versículo {(bookmark as any).verseId}
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() =>
                          removeBookmarkMutation.mutate({
                            verseId: (bookmark as any).verseId,
                          })
                        }
                        className="text-red-600 hover:text-red-700"
                      >
                        <Heart
                          className="w-5 h-5"
                          fill="currentColor"
                        />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setLocation("/")}
                    >
                      Ver Capítulo
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <Heart className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-600">
                Você ainda não tem nenhum marcador.
              </p>
              <p className="text-sm text-slate-500 mt-2">
                Clique no ícone de coração nos versículos para salvá-los.
              </p>
              <Button
                onClick={() => setLocation("/")}
                className="mt-4"
              >
                Começar a Explorar
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
