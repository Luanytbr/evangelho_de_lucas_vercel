import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Lightbulb, BookOpen } from "lucide-react";

export default function Curiosities() {
  const [, setLocation] = useLocation();

  const curiosities = [
    {
      title: "Lucas era Médico",
      content: "Lucas é o único evangelista que era médico. Isso se reflete em seu evangelho através de descrições médicas precisas de doenças e curas. Ele usa terminologia médica sofisticada que não aparece nos outros evangelhos.",
      icon: "🏥",
    },
    {
      title: "O Evangelho Mais Longo",
      content: "O Evangelho de Lucas é o mais longo dos quatro evangelhos, com 24 capítulos. Ele contém muitas histórias e parábolas únicas que não aparecem em Mateus, Marcos ou João.",
      icon: "📖",
    },
    {
      title: "Escrito para um Grego",
      content: "Lucas escreveu seu evangelho para Teófilo, um cristão grego. O nome 'Teófilo' significa 'amado de Deus'. Isso explica por que Lucas frequentemente traduz palavras aramaicas e explica costumes judeus.",
      icon: "🌍",
    },
    {
      title: "Ênfase em Mulheres",
      content: "Lucas dá destaque especial às mulheres em seu evangelho, algo incomum para a época. Ele menciona Maria, a mãe de Jesus, mais vezes que os outros evangelistas, e inclui histórias de mulheres como a viúva de Naim e a mulher pecadora.",
      icon: "👩",
    },
    {
      title: "Parábolas Únicas",
      content: "Lucas contém algumas das parábolas mais famosas que não aparecem em outros evangelhos: o Bom Samaritano (10:25-37), o Filho Pródigo (15:11-32) e o Publicano e o Fariseu (18:9-14).",
      icon: "🎭",
    },
    {
      title: "Ênfase na Oração",
      content: "Lucas destaca a importância da oração mais que qualquer outro evangelista. Ele menciona Jesus orando em momentos cruciais: no batismo, antes de escolher os apóstolos, na transfiguração e na cruz.",
      icon: "🙏",
    },
    {
      title: "O Evangelho da Alegria",
      content: "Lucas enfatiza a alegria e a paz em Cristo. A palavra 'alegria' aparece mais frequentemente em Lucas do que em qualquer outro evangelho. O evangelho começa com alegria (nascimento de Jesus) e termina com alegria (ressurreição).",
      icon: "😊",
    },
    {
      title: "Inclusão de Marginalizados",
      content: "Lucas mostra compaixão especial pelos marginalizados: publicanos, pecadores, pobres, leprosos e estrangeiros. Ele retrata Jesus como aquele que vem buscar e salvar os perdidos.",
      icon: "🤝",
    },
    {
      title: "Detalhes Únicos do Nascimento",
      content: "Apenas Lucas relata detalhes específicos do nascimento de Jesus: a visitação de Maria a Isabel, o cântico de Zacarias, a visitação dos pastores, e a apresentação de Jesus no templo.",
      icon: "👶",
    },
    {
      title: "Cronologia Precisa",
      content: "Lucas é conhecido por sua preocupação com a cronologia. Ele fornece datas específicas e referências históricas que ajudam a situar os eventos no contexto histórico do Império Romano.",
      icon: "📅",
    },
    {
      title: "O Espírito Santo em Destaque",
      content: "Lucas enfatiza o papel do Espírito Santo mais que qualquer outro evangelista. O Espírito Santo está envolvido no nascimento de João Batista, no batismo de Jesus, na tentação, e em todo o ministério de Jesus.",
      icon: "✨",
    },
    {
      title: "Milagres de Cura Detalhados",
      content: "Como médico, Lucas descreve as curas de Jesus com detalhes clínicos. Ele menciona 20 milagres em seu evangelho, muitos deles com descrições médicas precisas das doenças curadas.",
      icon: "⚕️",
    },
    {
      title: "A Parábola do Filho Pródigo",
      content: "Esta é uma das parábolas mais famosas de Jesus, contada apenas por Lucas. Ela ilustra o amor incondicional de Deus e a alegria da reconciliação. A parábola tem três personagens principais: o pai amoroso, o filho pródigo e o filho mais velho ciumento.",
      icon: "🏠",
    },
    {
      title: "O Bom Samaritano",
      content: "Apenas Lucas relata a parábola do Bom Samaritano, que desafia os preconceitos dos judeus contra os samaritanos. Ela ensina sobre amor ao próximo e compaixão transcultural.",
      icon: "🛣️",
    },
    {
      title: "Zaqueu, o Publicano",
      content: "A história de Zaqueu (19:1-10) é contada apenas por Lucas. Zaqueu era um publicano rico que se arrependeu e devolveu quatro vezes o que havia roubado. Jesus disse: 'Hoje veio salvação para esta casa'.",
      icon: "💰",
    },
    {
      title: "Autoridade Literária",
      content: "Lucas declara em seu prólogo (1:1-4) que investigou cuidadosamente os eventos e os escreveu em ordem. Isso o torna o único evangelista que explica seu método de pesquisa.",
      icon: "✍️",
    },
    {
      title: "Referências Históricas",
      content: "Lucas menciona vários governantes e eventos históricos que podem ser verificados: Augusto César, Quirino, Herodes, Pilatos e o tetrarca Felipe. Isso ajuda a datar os eventos com precisão.",
      icon: "🏛️",
    },
    {
      title: "O Ladrão na Cruz",
      content: "Apenas Lucas relata a conversa de Jesus com o ladrão na cruz. O ladrão pede a Jesus: 'Lembra-te de mim quando entrares no teu reino', e Jesus responde: 'Hoje estarás comigo no paraíso'.",
      icon: "✝️",
    },
    {
      title: "Ênfase na Salvação Universal",
      content: "Lucas enfatiza que a salvação é para todos, não apenas para os judeus. Ele inclui genealogia de Jesus até Adão (não apenas até Abraão) para mostrar que Jesus é Salvador da humanidade toda.",
      icon: "🌎",
    },
    {
      title: "O Evangelho do Homem Perfeito",
      content: "Enquanto Mateus apresenta Jesus como Rei, Marcos como Servo, e João como Deus, Lucas apresenta Jesus como o Homem Perfeito - totalmente humano, compassivo e identificado com a humanidade.",
      icon: "👤",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Curiosidades Bíblicas</h1>
          <p className="text-slate-600 mt-2">
            Fatos interessantes sobre o Evangelho de Lucas
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <Lightbulb className="w-8 h-8 text-blue-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-blue-900 mb-2">
                    Descubra Fatos Fascinantes
                  </h3>
                  <p className="text-sm text-blue-800">
                    Explore curiosidades, detalhes únicos e informações interessantes sobre o Evangelho de Lucas,
                    seu autor e os ensinamentos de Jesus.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {curiosities.map((curiosity, index) => (
            <Card
              key={index}
              className="hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => {}}
            >
              <CardHeader>
                <div className="flex items-start gap-3">
                  <span className="text-3xl">{curiosity.icon}</span>
                  <CardTitle className="text-lg">{curiosity.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-700 leading-relaxed text-sm">
                  {curiosity.content}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200 max-w-2xl mx-auto">
            <CardContent className="pt-8 pb-8">
              <BookOpen className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                Quer Aprender Mais?
              </h3>
              <p className="text-slate-600 mb-6">
                Explore os capítulos completos de Lucas para descobrir mais detalhes e ensinamentos profundos.
              </p>
              <div className="flex gap-4 justify-center">
                <Button onClick={() => setLocation("/capitulos/1")}>
                  Começar a Ler
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setLocation("/busca")}
                >
                  Buscar Tópicos
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
