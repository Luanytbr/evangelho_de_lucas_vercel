import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Brain, CheckCircle, XCircle } from "lucide-react";
import { useState } from "react";

export default function Quiz() {
  const [, setLocation] = useLocation();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);

  const questions = [
    {
      question: "Qual é a profissão de Lucas?",
      options: ["Médico", "Pescador", "Publicano", "Carpinteiro"],
      correct: 0,
      explanation: "Lucas era médico, o único evangelista com essa profissão. Isso se reflete em suas descrições médicas precisas.",
    },
    {
      question: "Para quem Lucas escreveu seu evangelho?",
      options: ["Os judeus", "Teófilo, um cristão grego", "Os romanos", "Todos os povos"],
      correct: 1,
      explanation: "Lucas escreveu para Teófilo, cujo nome significa 'amado de Deus'. Isso explica por que ele traduz palavras aramaicas.",
    },
    {
      question: "Qual é a parábola mais famosa contada apenas por Lucas?",
      options: ["O Semeador", "O Filho Pródigo", "O Bom Samaritano", "Os Dez Talentos"],
      correct: 2,
      explanation: "Embora o Filho Pródigo também seja único em Lucas, o Bom Samaritano é uma das mais famosas.",
    },
    {
      question: "Quantos milagres Lucas relata em seu evangelho?",
      options: ["10", "15", "20", "25"],
      correct: 2,
      explanation: "Lucas relata 20 milagres de Jesus, mais que qualquer outro evangelista.",
    },
    {
      question: "Qual é o tema principal do Evangelho de Lucas?",
      options: ["Jesus como Rei", "Jesus como Servo", "Jesus como Homem Perfeito", "Jesus como Deus"],
      correct: 2,
      explanation: "Lucas apresenta Jesus como o Homem Perfeito, totalmente humano e compassivo.",
    },
    {
      question: "Quantos capítulos tem o Evangelho de Lucas?",
      options: ["20", "22", "24", "26"],
      correct: 2,
      explanation: "Lucas tem 24 capítulos, o mais longo dos quatro evangelhos.",
    },
    {
      question: "Qual é a parábola que ensina sobre amor ao próximo transcultural?",
      options: ["O Semeador", "O Bom Samaritano", "O Filho Pródigo", "A Ovelha Perdida"],
      correct: 1,
      explanation: "O Bom Samaritano desafia os preconceitos dos judeus contra os samaritanos.",
    },
    {
      question: "Quem foi o precursor de Jesus?",
      options: ["Pedro", "João Batista", "Tiago", "Filipe"],
      correct: 1,
      explanation: "João Batista preparou o caminho para Jesus e o batizou.",
    },
    {
      question: "Qual é a história de um publicano rico que se arrependeu?",
      options: ["Mateus", "Zaqueu", "Levi", "Simão"],
      correct: 1,
      explanation: "Zaqueu era um publicano rico que se arrependeu e devolveu quatro vezes o que havia roubado.",
    },
    {
      question: "Em qual parábola um pai amoroso recebe de volta seu filho que desperdiçou sua herança?",
      options: ["O Administrador Infiel", "O Filho Pródigo", "O Homem Rico e Lázaro", "Os Dez Leprosos"],
      correct: 1,
      explanation: "O Filho Pródigo é uma das parábolas mais famosas que ilustra o amor incondicional de Deus.",
    },
    {
      question: "Qual é a ênfase especial de Lucas em relação às mulheres?",
      options: ["Ele as ignora", "Ele dá destaque especial a elas", "Ele as critica", "Ele não menciona mulheres"],
      correct: 1,
      explanation: "Lucas dá destaque especial às mulheres, algo incomum para a época.",
    },
    {
      question: "Qual é o evangelho que começa com a genealogia de Jesus até Adão?",
      options: ["Mateus", "Marcos", "Lucas", "João"],
      correct: 2,
      explanation: "Lucas rastreia a genealogia de Jesus até Adão para mostrar que Jesus é Salvador da humanidade toda.",
    },
    {
      question: "Qual é a história de um homem que foi curado e voltou para agradecer a Jesus?",
      options: ["Os Dez Leprosos", "O Paralítico", "O Homem Cego", "O Homem Surdo"],
      correct: 0,
      explanation: "Dos dez leprosos curados, apenas um voltou para agradecer a Jesus.",
    },
    {
      question: "Qual é a parábola que ensina sobre persistência na oração?",
      options: ["A Ovelha Perdida", "A Viúva Persistente", "O Semeador", "O Farol"],
      correct: 1,
      explanation: "A Viúva Persistente ensina que devemos ser persistentes em nossas orações.",
    },
    {
      question: "Qual é o milagre onde Jesus alimenta cinco mil pessoas?",
      options: ["A Pesca Milagrosa", "A Alimentação dos Cinco Mil", "A Calmaria da Tempestade", "A Ressurreição de Lázaro"],
      correct: 1,
      explanation: "Com apenas cinco pães e dois peixes, Jesus alimenta cinco mil homens além de mulheres e crianças.",
    },
    {
      question: "Qual é a promessa de Jesus ao ladrão na cruz?",
      options: ["Você será perdoado", "Você ressuscitará", "Hoje estarás comigo no paraíso", "Você será salvo"],
      correct: 2,
      explanation: "Jesus promete ao ladrão arrependido que ele estará com ele no paraíso naquele mesmo dia.",
    },
  ];

  const handleAnswerClick = (index: number) => {
    if (answered) return;
    setSelectedAnswer(index);
    setAnswered(true);

    if (index === questions[currentQuestion].correct) {
      setScore(score + 1);
    }
  };

  const handleNext = () => {
    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < questions.length) {
      setCurrentQuestion(nextQuestion);
      setSelectedAnswer(null);
      setAnswered(false);
    } else {
      setShowScore(true);
    }
  };

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowScore(false);
    setSelectedAnswer(null);
    setAnswered(false);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Quiz Interativo</h1>
          <p className="text-slate-600 mt-2">
            Teste seus conhecimentos sobre o Evangelho de Lucas
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12 max-w-2xl">
        {showScore ? (
          <Card className="border-2 border-blue-200 bg-blue-50">
            <CardContent className="pt-8 pb-8 text-center">
              <Brain className="w-16 h-16 text-blue-600 mx-auto mb-4" />
              <h2 className="text-3xl font-bold text-slate-900 mb-2">
                Resultado Final
              </h2>
              <p className="text-5xl font-bold text-blue-600 mb-4">
                {score} / {questions.length}
              </p>
              <p className="text-xl text-slate-700 mb-6">
                Você acertou {Math.round((score / questions.length) * 100)}% das questões!
              </p>

              {score === questions.length && (
                <p className="text-lg text-green-600 font-semibold mb-4">
                  🎉 Parabéns! Você é um especialista em Lucas!
                </p>
              )}
              {score >= questions.length * 0.8 && score < questions.length && (
                <p className="text-lg text-blue-600 font-semibold mb-4">
                  ⭐ Excelente! Você tem um ótimo conhecimento sobre Lucas!
                </p>
              )}
              {score >= questions.length * 0.6 && score < questions.length * 0.8 && (
                <p className="text-lg text-amber-600 font-semibold mb-4">
                  👍 Bom! Continue estudando para aprender mais!
                </p>
              )}
              {score < questions.length * 0.6 && (
                <p className="text-lg text-orange-600 font-semibold mb-4">
                  📚 Continue estudando! Há muito mais para aprender sobre Lucas!
                </p>
              )}

              <div className="flex gap-4 justify-center">
                <Button onClick={restartQuiz}>Refazer Quiz</Button>
                <Button variant="outline" onClick={() => setLocation("/")}>
                  Voltar ao Início
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* Progress */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-semibold text-slate-600">
                    Questão {currentQuestion + 1} de {questions.length}
                  </span>
                  <span className="text-sm font-semibold text-blue-600">
                    Acertos: {score}
                  </span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full transition-all"
                    style={{
                      width: `${((currentQuestion + 1) / questions.length) * 100}%`,
                    }}
                  ></div>
                </div>
              </CardContent>
            </Card>

            {/* Question */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">
                  {questions[currentQuestion].question}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Options */}
                <div className="space-y-3">
                  {questions[currentQuestion].options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => handleAnswerClick(index)}
                      disabled={answered}
                      className={`w-full p-4 text-left rounded-lg border-2 transition-all ${
                        selectedAnswer === index
                          ? index === questions[currentQuestion].correct
                            ? "border-green-500 bg-green-50"
                            : "border-red-500 bg-red-50"
                          : "border-slate-200 hover:border-blue-300 hover:bg-blue-50"
                      } ${answered ? "cursor-not-allowed" : "cursor-pointer"}`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{option}</span>
                        {selectedAnswer === index && (
                          <>
                            {index === questions[currentQuestion].correct ? (
                              <CheckCircle className="w-5 h-5 text-green-600" />
                            ) : (
                              <XCircle className="w-5 h-5 text-red-600" />
                            )}
                          </>
                        )}
                      </div>
                    </button>
                  ))}
                </div>

                {/* Explanation */}
                {answered && (
                  <div
                    className={`p-4 rounded-lg ${
                      selectedAnswer === questions[currentQuestion].correct
                        ? "bg-green-50 border-l-4 border-green-600"
                        : "bg-red-50 border-l-4 border-red-600"
                    }`}
                  >
                    <p className="text-sm font-semibold mb-1">
                      {selectedAnswer === questions[currentQuestion].correct
                        ? "✓ Correto!"
                        : "✗ Incorreto"}
                    </p>
                    <p className="text-sm text-slate-700">
                      {questions[currentQuestion].explanation}
                    </p>
                  </div>
                )}

                {/* Next Button */}
                {answered && (
                  <Button
                    onClick={handleNext}
                    className="w-full mt-4"
                  >
                    {currentQuestion === questions.length - 1
                      ? "Ver Resultado"
                      : "Próxima Questão"}
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
