import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { MapPin, Info } from "lucide-react";
import { useState } from "react";

export default function Maps() {
  const [, setLocation] = useLocation();
  const [selectedLocation, setSelectedLocation] = useState<number | null>(0);

  const locations = [
    {
      name: "Nazaré",
      region: "Galileia",
      description: "Cidade natal de Jesus. Aqui Jesus cresceu e foi criado. Nazaré era uma pequena aldeia no norte de Israel.",
      significance: "Local do nascimento e infância de Jesus",
      mentions: "Lucas 1:26, 2:4, 2:39, 4:16",
      historicalContext: "Nazaré era uma aldeia obscura no século I. Não é mencionada no Antigo Testamento. Era conhecida por sua população humilde.",
      coordinates: "32.7000° N, 35.3000° E",
    },
    {
      name: "Belém",
      region: "Judeia",
      description: "Cidade onde Jesus nasceu. Belém era a cidade de Davi e era considerada importante na tradição judaica.",
      significance: "Local do nascimento de Jesus",
      mentions: "Lucas 2:4-7, 2:15-16",
      historicalContext: "Belém era uma pequena cidade a cerca de 10 km de Jerusalém. Era conhecida como a cidade de Davi.",
      coordinates: "31.9454° N, 35.2023° E",
    },
    {
      name: "Jerusalém",
      region: "Judeia",
      description: "A capital de Israel e o centro religioso do judaísmo. Jerusalém era o local do Templo e da autoridade religiosa.",
      significance: "Local da morte e ressurreição de Jesus",
      mentions: "Lucas 2:22-38, 19:28-24:53",
      historicalContext: "Jerusalém era a cidade mais importante de Israel. Era cercada por muros e tinha uma população de cerca de 50.000-100.000 pessoas.",
      coordinates: "31.7683° N, 35.2137° E",
    },
    {
      name: "Jericó",
      region: "Judeia",
      description: "Cidade antiga no Vale do Jordão. Jericó era uma cidade importante na rota entre Galileia e Jerusalém.",
      significance: "Local onde Jesus curou o cego e encontrou Zaqueu",
      mentions: "Lucas 18:35-43, 19:1-10",
      historicalContext: "Jericó era uma oásis no deserto. Era a cidade mais antiga do mundo e tinha uma longa história.",
      coordinates: "31.8627° N, 35.4443° E",
    },
    {
      name: "Cafarnaum",
      region: "Galileia",
      description: "Cidade no Mar da Galileia onde Jesus baseou grande parte de Seu ministério. Era uma cidade de pescadores.",
      significance: "Centro do ministério de Jesus na Galileia",
      mentions: "Lucas 4:31-37, 7:1-10",
      historicalContext: "Cafarnaum era uma cidade próspera de pescadores. Tinha uma sinagoga onde Jesus frequentemente ensinava.",
      coordinates: "32.8833° N, 35.5667° E",
    },
    {
      name: "Mar da Galileia",
      region: "Galileia",
      description: "Lago de água doce onde Jesus ensinou e realizou milagres. Era importante para a economia local.",
      significance: "Local de milagres e ensinamentos de Jesus",
      mentions: "Lucas 5:1-11, 8:22-25",
      historicalContext: "O Mar da Galileia era a principal fonte de alimento para a região. Era cercado por cidades de pescadores.",
      coordinates: "32.8167° N, 35.5000° E",
    },
    {
      name: "Samaria",
      region: "Centro de Israel",
      description: "Região entre Judeia e Galileia. Os samaritanos eram desprezados pelos judeus por razões históricas e religiosas.",
      significance: "Local onde Jesus ensinou sobre o amor ao próximo",
      mentions: "Lucas 10:25-37, 17:11-19",
      historicalContext: "Samaria era uma região com uma história complexa. Os samaritanos tinham sua própria religião e eram marginalizados pelos judeus.",
      coordinates: "32.1833° N, 35.2000° E",
    },
    {
      name: "Betânia",
      region: "Judeia",
      description: "Aldeia perto de Jerusalém, lar de Marta, Maria e Lázaro. Era um lugar importante para Jesus.",
      significance: "Local onde Jesus frequentemente se hospedava",
      mentions: "Lucas 10:38-42, 24:50",
      historicalContext: "Betânia era uma aldeia pequena a cerca de 3 km de Jerusalém. Era um refúgio para Jesus durante Sua última semana.",
      coordinates: "31.7733° N, 35.2783° E",
    },
    {
      name: "Getsêmani",
      region: "Judeia",
      description: "Jardim no Monte das Oliveiras onde Jesus orou na noite antes de Sua crucificação.",
      significance: "Local da oração e prisão de Jesus",
      mentions: "Lucas 22:39-53",
      historicalContext: "Getsêmani era um jardim de oliveiras. Era um lugar onde Jesus frequentemente ia para orar.",
      coordinates: "31.7764° N, 35.2386° E",
    },
    {
      name: "Monte das Oliveiras",
      region: "Judeia",
      description: "Montanha perto de Jerusalém onde Jesus frequentemente ensinava e orava.",
      significance: "Local da ascensão de Jesus",
      mentions: "Lucas 19:29, 21:37, 22:39, 24:50",
      historicalContext: "O Monte das Oliveiras era um lugar importante para a tradição judaica. Era considerado o local onde o Messias apareceria.",
      coordinates: "31.7797° N, 35.2432° E",
    },
    {
      name: "Templo de Jerusalém",
      region: "Jerusalém",
      description: "O centro religioso do judaísmo. Era o lugar mais sagrado para os judeus e era onde Jesus frequentemente ensinava.",
      significance: "Local onde Jesus ensinava e realizava milagres",
      mentions: "Lucas 2:22-38, 19:45-48, 24:53",
      historicalContext: "O Templo era um edifício magnífico construído por Herodes. Era o centro da vida religiosa judaica.",
      coordinates: "31.7683° N, 35.2345° E",
    },
    {
      name: "Deserto de Judeia",
      region: "Judeia",
      description: "Região árida onde João Batista pregava e onde Jesus foi tentado.",
      significance: "Local do batismo de Jesus e Sua tentação",
      mentions: "Lucas 3:1-6, 4:1-13",
      historicalContext: "O Deserto de Judeia era uma região árida e hostil. Era um lugar onde muitos profetas e pregadores iam para se preparar espiritualmente.",
      coordinates: "31.9000° N, 35.4000° E",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Mapas Interativos</h1>
          <p className="text-slate-600 mt-2">
            Explore os locais geográficos mencionados no Evangelho de Lucas
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <MapPin className="w-8 h-8 text-blue-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-blue-900 mb-2">
                    Descubra os Locais de Lucas
                  </h3>
                  <p className="text-sm text-blue-800">
                    Explore os 12 locais principais mencionados no Evangelho de Lucas. Clique em cada local
                    para aprender sobre sua história, significância e contexto histórico.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Location List */}
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Locais</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {locations.map((location, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedLocation(index)}
                      className={`w-full text-left p-3 rounded-lg transition-all ${
                        selectedLocation === index
                          ? "bg-blue-600 text-white"
                          : "bg-slate-100 text-slate-900 hover:bg-slate-200"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 flex-shrink-0" />
                        <span className="font-medium text-sm">{location.name}</span>
                      </div>
                      <span className="text-xs opacity-75">{location.region}</span>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Location Details */}
          <div className="md:col-span-2">
            {selectedLocation !== null && (
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div>
                    <CardTitle className="text-2xl">
                      {locations[selectedLocation].name}
                    </CardTitle>
                    <p className="text-sm text-slate-500 mt-2">
                      {locations[selectedLocation].region}
                    </p>
                    <p className="text-xs text-slate-400 mt-1">
                      Coordenadas: {locations[selectedLocation].coordinates}
                    </p>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-slate-900 mb-2">Descrição</h4>
                    <p className="text-slate-700">
                      {locations[selectedLocation].description}
                    </p>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-600">
                    <p className="text-sm text-slate-700">
                      <span className="font-semibold">Significância:</span>{" "}
                      {locations[selectedLocation].significance}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-semibold text-slate-900 mb-2">
                      Menções em Lucas
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {locations[selectedLocation].mentions.split(", ").map((mention, idx) => (
                        <button
                          key={idx}
                          onClick={() => {
                            const chapterNum = parseInt(mention.split(":")[0].split(" ")[1]);
                            setLocation(`/capitulos/${chapterNum}`);
                          }}
                          className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm hover:bg-blue-200 transition"
                        >
                          {mention}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-slate-900 mb-2">
                      Contexto Histórico
                    </h4>
                    <p className="text-slate-700">
                      {locations[selectedLocation].historicalContext}
                    </p>
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const chapterNum = parseInt(
                        locations[selectedLocation].mentions.split(",")[0].split(":")[0].split(" ")[1]
                      );
                      setLocation(`/capitulos/${chapterNum}`);
                    }}
                  >
                    Ler Capítulos Relacionados
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
            <CardContent className="pt-8 pb-8">
              <Info className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                Compreenda o Contexto Geográfico
              </h3>
              <p className="text-slate-600 mb-6">
                Entender os locais onde Jesus ministrou ajuda a compreender melhor Seus ensinamentos e ações.
              </p>
              <Button onClick={() => setLocation("/capitulos/1")}>
                Explorar os Capítulos
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
