import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { BookOpen, ChevronDown } from "lucide-react";
import { useState } from "react";

export default function Theology() {
  const [, setLocation] = useLocation();
  const [expandedStudy, setExpandedStudy] = useState<number | null>(0);

  const studies = [
    {
      title: "A Salvação em Lucas",
      subtitle: "O Evangelho da Salvação Universal",
      content: "Lucas enfatiza que a salvação é oferecida a todos, não apenas aos judeus. Jesus veio para buscar e salvar os perdidos (19:10). A salvação é um presente de Deus, não algo que podemos ganhar por nossas obras. Lucas mostra que a salvação envolve arrependimento, fé e transformação pessoal.",
      keyVerses: ["Lucas 19:10", "Lucas 15:1-7", "Lucas 7:36-50"],
      doctrine: "Soteriologia (Doutrina da Salvação)",
    },
    {
      title: "A Graça de Deus",
      subtitle: "O Favor Imerecido de Deus",
      content: "A graça é um tema central em Lucas. Deus oferece salvação não porque merecemos, mas por Sua graça. Isso é visto na história do Filho Pródigo (15:11-32), onde o pai amoroso recebe seu filho de volta sem condenação. A graça de Deus é maior que qualquer pecado.",
      keyVerses: ["Lucas 15:11-32", "Lucas 1:28", "Lucas 1:46-55"],
      doctrine: "Soteriologia (Doutrina da Salvação)",
    },
    {
      title: "A Fé e o Arrependimento",
      subtitle: "Mudança de Coração e Mente",
      content: "Lucas enfatiza que a fé genuína resulta em arrependimento. Não é apenas crer intelectualmente, mas confiar completamente em Deus e mudar de direção. O arrependimento não é apenas sentir remorso, mas virar-se de longe do pecado para voltar para Deus.",
      keyVerses: ["Lucas 3:8", "Lucas 5:32", "Lucas 13:3"],
      doctrine: "Soteriologia (Doutrina da Salvação)",
    },
    {
      title: "O Espírito Santo",
      subtitle: "O Poder de Deus em Ação",
      content: "Lucas dá destaque especial ao Espírito Santo. O Espírito Santo está envolvido no nascimento de João Batista, no batismo de Jesus, na tentação, e em todo o ministério de Jesus. O Espírito Santo capacita os crentes para testemunhar e servir a Deus.",
      keyVerses: ["Lucas 1:15", "Lucas 3:22", "Lucas 4:1-13", "Lucas 12:12"],
      doctrine: "Pneumatologia (Doutrina do Espírito Santo)",
    },
    {
      title: "A Humanidade de Jesus",
      subtitle: "O Homem Perfeito",
      content: "Lucas apresenta Jesus como totalmente humano. Ele nasceu, cresceu, foi tentado, sofreu fome e sede, chorou, morreu. Mas apesar de Sua humanidade completa, Ele foi sem pecado e perfeito. Isso mostra que Jesus é o Homem Perfeito que nos redime.",
      keyVerses: ["Lucas 2:40", "Lucas 4:1-13", "Lucas 22:44", "Lucas 23:46"],
      doctrine: "Cristologia (Doutrina de Cristo)",
    },
    {
      title: "A Divindade de Jesus",
      subtitle: "O Filho de Deus",
      content: "Apesar de enfatizar a humanidade de Jesus, Lucas também afirma Sua divindade. Jesus é chamado de Filho de Deus, tem poder para perdoar pecados, controlar a natureza, ressuscitar mortos e conhecer os pensamentos das pessoas. Sua ressurreição prova Sua divindade.",
      keyVerses: ["Lucas 1:35", "Lucas 5:24", "Lucas 8:25", "Lucas 24:1-12"],
      doctrine: "Cristologia (Doutrina de Cristo)",
    },
    {
      title: "O Reino de Deus",
      subtitle: "O Reinado de Deus",
      content: "Jesus frequentemente ensina sobre o Reino de Deus. Não é um lugar físico, mas o domínio da vontade de Deus. O Reino de Deus está presente agora nos crentes, mas será consumado quando Jesus voltar. Entrar no Reino requer arrependimento e fé.",
      keyVerses: ["Lucas 4:43", "Lucas 9:2", "Lucas 17:20-21", "Lucas 22:29-30"],
      doctrine: "Escatologia (Doutrina dos Últimos Tempos)",
    },
    {
      title: "A Ressurreição e a Vida Eterna",
      subtitle: "Esperança de Vida Após a Morte",
      content: "A ressurreição de Jesus é o evento central do evangelho. Prova Seu poder sobre a morte e oferece esperança de vida eterna para todos os crentes. A ressurreição não é apenas um evento histórico, mas a base da fé cristã e da esperança de vida eterna.",
      keyVerses: ["Lucas 24:1-12", "Lucas 24:25-27", "Lucas 24:44-47"],
      doctrine: "Escatologia (Doutrina dos Últimos Tempos)",
    },
    {
      title: "O Amor de Deus",
      subtitle: "Deus é Amor",
      content: "Lucas enfatiza o amor de Deus por toda a humanidade. Deus ama os pecadores, os pobres, os marginalizados, os estrangeiros. O amor de Deus é incondicional e não depende de nossos méritos. Jesus demonstra esse amor através de Seu ministério e Sua morte.",
      keyVerses: ["Lucas 15:1-7", "Lucas 7:36-50", "Lucas 19:1-10", "Lucas 23:34"],
      doctrine: "Teologia Sistemática (Doutrina de Deus)",
    },
    {
      title: "A Compaixão e a Misericórdia",
      subtitle: "Deus se Compadece dos Aflitos",
      content: "Lucas mostra que Deus é compassivo e misericordioso. Jesus se compadece dos enfermos, dos pobres, dos enlutados e dos pecadores. A compaixão não é apenas um sentimento, mas resulta em ação. Devemos imitar a compaixão de Deus para com os outros.",
      keyVerses: ["Lucas 7:13", "Lucas 15:20", "Lucas 10:25-37"],
      doctrine: "Teologia Sistemática (Doutrina de Deus)",
    },
    {
      title: "A Justiça Social",
      subtitle: "Cuidado pelos Pobres e Necessitados",
      content: "Lucas enfatiza a importância de cuidar dos pobres e necessitados. Jesus ensina que devemos compartilhar nossas posses com os pobres, acolher os estrangeiros e cuidar dos doentes. A fé genuína resulta em ação social e compaixão pelos marginalizados.",
      keyVerses: ["Lucas 4:18", "Lucas 12:33", "Lucas 16:19-31"],
      doctrine: "Ética Cristã",
    },
    {
      title: "O Arrependimento e a Redenção",
      subtitle: "Transformação Pessoal",
      content: "O arrependimento não é apenas sentir remorso, mas virar-se completamente de longe do pecado. A redenção é o resultado do arrependimento e da fé. Quando nos arrependemos, Deus nos redime e nos transforma em novas pessoas. Isso é visto na história de Zaqueu e da mulher pecadora.",
      keyVerses: ["Lucas 19:1-10", "Lucas 7:36-50", "Lucas 15:11-32"],
      doctrine: "Soteriologia (Doutrina da Salvação)",
    },
    {
      title: "A Oração e a Comunhão com Deus",
      subtitle: "Relacionamento Íntimo com Deus",
      content: "Lucas enfatiza a importância da oração. Jesus frequentemente se retira para orar, e ensina Seus discípulos a orar. A oração não é apenas pedir a Deus, mas comunhão com Ele. Através da oração, desenvolvemos um relacionamento íntimo com Deus e experimentamos Sua presença.",
      keyVerses: ["Lucas 3:21", "Lucas 5:16", "Lucas 6:12", "Lucas 11:1-13"],
      doctrine: "Espiritualidade Cristã",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Estudos Teológicos</h1>
          <p className="text-slate-600 mt-2">
            Aprofunde seu conhecimento sobre as doutrinas cristãs em Lucas
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <BookOpen className="w-8 h-8 text-blue-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-blue-900 mb-2">
                    Explore Temas Teológicos Profundos
                  </h3>
                  <p className="text-sm text-blue-800">
                    Estes estudos exploram as doutrinas cristãs fundamentais encontradas no Evangelho de Lucas.
                    Cada estudo inclui versículos-chave e referências para aprofundamento.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          {studies.map((study, index) => (
            <Card
              key={index}
              className="hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() =>
                setExpandedStudy(expandedStudy === index ? null : index)
              }
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg">{study.title}</CardTitle>
                    <p className="text-sm text-slate-500 mt-1">
                      {study.subtitle}
                    </p>
                    <div className="mt-2">
                      <span className="inline-block px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded font-semibold">
                        {study.doctrine}
                      </span>
                    </div>
                  </div>
                  <ChevronDown
                    className={`w-5 h-5 text-slate-400 transition-transform flex-shrink-0 ${
                      expandedStudy === index ? "rotate-180" : ""
                    }`}
                  />
                </div>
              </CardHeader>

              {expandedStudy === index && (
                <CardContent className="space-y-4 border-t pt-4">
                  <div>
                    <p className="text-slate-700 leading-relaxed">
                      {study.content}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-semibold text-slate-900 mb-2">
                      Versículos-Chave:
                    </h4>
                    <div className="space-y-2">
                      {study.keyVerses.map((verse, idx) => (
                        <button
                          key={idx}
                          onClick={() => {
                            const chapterNum = parseInt(verse.split(":")[0].split(" ")[1]);
                            setLocation(`/capitulos/${chapterNum}`);
                          }}
                          className="block text-sm text-blue-600 hover:text-blue-800 hover:underline text-left"
                        >
                          → {verse}
                        </button>
                      ))}
                    </div>
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setLocation("/capitulos/1")}
                  >
                    Explorar Capítulos
                  </Button>
                </CardContent>
              )}
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="pt-8 pb-8">
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                Aprofunde Seu Conhecimento Teológico
              </h3>
              <p className="text-slate-600 mb-6">
                Combine estes estudos teológicos com a leitura dos capítulos para uma compreensão mais profunda.
              </p>
              <Button onClick={() => setLocation("/capitulos/1")}>
                Começar a Ler os Capítulos
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
