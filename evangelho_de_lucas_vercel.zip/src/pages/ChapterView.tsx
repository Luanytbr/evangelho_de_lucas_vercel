import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Heart, MessageSquare, Plus } from "lucide-react";
import { useLocation, useRoute } from "wouter";
import { useState } from "react";

export default function ChapterView() {
  const { isAuthenticated } = useAuth();
  const [, params] = useRoute("/capitulos/:chapterNumber");
  const [, setLocation] = useLocation();
  const chapterNumber = params?.chapterNumber ? parseInt(params.chapterNumber) : 1;

  const { data: chapter, isLoading } = trpc.chapters.getByNumber.useQuery({
    chapterNumber,
  });

  const { data: bookmarks } = trpc.bookmarks.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const addBookmarkMutation = trpc.bookmarks.add.useMutation();
  const removeBookmarkMutation = trpc.bookmarks.remove.useMutation();
  const addNoteMutation = trpc.notes.add.useMutation();

  const [noteContent, setNoteContent] = useState("");
  const [selectedVerseId, setSelectedVerseId] = useState<number | null>(null);

  const isVerseBookmarked = (verseId: number) => {
    return bookmarks?.some((b) => b.verseId === verseId);
  };

  const handleToggleBookmark = (verseId: number) => {
    if (isVerseBookmarked(verseId)) {
      removeBookmarkMutation.mutate({ verseId });
    } else {
      addBookmarkMutation.mutate({ verseId });
    }
  };

  const handleAddNote = (verseId: number) => {
    if (noteContent.trim()) {
      addNoteMutation.mutate(
        { verseId, content: noteContent },
        {
          onSuccess: () => {
            setNoteContent("");
            setSelectedVerseId(null);
          },
        }
      );
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 py-8">
        <div className="container mx-auto px-4">
          <p className="text-center text-slate-600">Carregando capítulo...</p>
        </div>
      </div>
    );
  }

  if (!chapter) {
    return (
      <div className="min-h-screen bg-slate-50 py-8">
        <div className="container mx-auto px-4">
          <p className="text-center text-slate-600">Capítulo não encontrado.</p>
          <div className="text-center mt-4">
            <Button onClick={() => setLocation("/")}>Voltar para Home</Button>
          </div>
        </div>
      </div>
    );
  }

  const themes = chapter.themes ? JSON.parse(chapter.themes) : [];
  const keyFigures = chapter.keyFigures ? JSON.parse(chapter.keyFigures) : [];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Capítulo {chapter.chapterNumber}
          </h1>
          <h2 className="text-xl text-slate-600">{chapter.title}</h2>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Context */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Contexto Histórico</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-700 leading-relaxed">
                  {chapter.context}
                </p>
              </CardContent>
            </Card>

            {/* Verses */}
            <div className="space-y-4">
              {chapter.verses && chapter.verses.length > 0 ? (
                chapter.verses.map((verse) => (
                  <Card key={verse.id} className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-base">
                            Versículo {verse.verseNumber}
                          </CardTitle>
                        </div>
                        {isAuthenticated && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() =>
                              handleToggleBookmark(verse.id)
                            }
                            className={
                              isVerseBookmarked(verse.id)
                                ? "text-red-600"
                                : "text-slate-400"
                            }
                          >
                            <Heart
                              className="w-5 h-5"
                              fill={
                                isVerseBookmarked(verse.id)
                                  ? "currentColor"
                                  : "none"
                              }
                            />
                          </Button>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-600">
                        <p className="text-slate-800 italic leading-relaxed">
                          "{verse.text}"
                        </p>
                      </div>

                      {verse.commentary && (
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-slate-700 font-semibold">
                            <MessageSquare className="w-4 h-4" />
                            Comentário
                          </div>
                          <p className="text-slate-700 leading-relaxed">
                            {verse.commentary}
                          </p>
                        </div>
                      )}

                      {isAuthenticated && (
                        <div className="pt-4 border-t">
                          {selectedVerseId === verse.id ? (
                            <div className="space-y-2">
                              <textarea
                                value={noteContent}
                                onChange={(e) =>
                                  setNoteContent(e.target.value)
                                }
                                placeholder="Adicione uma nota pessoal..."
                                className="w-full p-2 border rounded-lg text-sm"
                                rows={3}
                              />
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  onClick={() =>
                                    handleAddNote(verse.id)
                                  }
                                  disabled={
                                    addNoteMutation.isPending ||
                                    !noteContent.trim()
                                  }
                                >
                                  Salvar Nota
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => {
                                    setSelectedVerseId(null);
                                    setNoteContent("");
                                  }}
                                >
                                  Cancelar
                                </Button>
                              </div>
                            </div>
                          ) : (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedVerseId(verse.id)}
                            >
                              <Plus className="w-4 h-4 mr-2" />
                              Adicionar Nota
                            </Button>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))
              ) : (
                <p className="text-center text-slate-600">
                  Nenhum versículo disponível para este capítulo.
                </p>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Themes */}
            {themes.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Temas Principais</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {themes.map((theme: string, idx: number) => (
                      <div
                        key={idx}
                        className="px-3 py-2 bg-blue-100 text-blue-800 rounded-full text-sm"
                      >
                        {theme}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Key Figures */}
            {keyFigures.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Personagens Principais</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {keyFigures.map((figure: string, idx: number) => (
                      <div
                        key={idx}
                        className="px-3 py-2 bg-green-100 text-green-800 rounded-full text-sm"
                      >
                        {figure}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Navigation */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Navegação</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() =>
                    setLocation(
                      `/capitulos/${Math.max(1, chapterNumber - 1)}`
                    )
                  }
                  disabled={chapterNumber === 1}
                >
                  ← Capítulo Anterior
                </Button>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() =>
                    setLocation(
                      `/capitulos/${Math.min(24, chapterNumber + 1)}`
                    )
                  }
                  disabled={chapterNumber === 24}
                >
                  Próximo Capítulo →
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
