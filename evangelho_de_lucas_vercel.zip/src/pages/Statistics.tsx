import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { BarChart3, BookOpen, Heart, LogIn } from "lucide-react";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";

export default function Statistics() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  const { data: bookmarks } = trpc.bookmarks.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: notes } = trpc.notes.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: chapters } = trpc.chapters.list.useQuery();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-50">
        <header className="bg-white border-b shadow-sm">
          <div className="container mx-auto px-4 py-4">
            <Button
              variant="ghost"
              onClick={() => setLocation("/")}
              className="mb-4"
            >
              ← Voltar
            </Button>
            <h1 className="text-3xl font-bold text-slate-900">Minhas Estatísticas</h1>
          </div>
        </header>

        <div className="container mx-auto px-4 py-12">
          <Card className="max-w-md mx-auto">
            <CardContent className="py-12 text-center">
              <LogIn className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-600 mb-4">
                Você precisa estar autenticado para acessar suas estatísticas.
              </p>
              <Button
                onClick={() => (window.location.href = getLoginUrl())}
              >
                Fazer Login
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const totalChapters = chapters?.length || 0;
  const totalBookmarks = bookmarks?.length || 0;
  const totalNotes = notes?.length || 0;

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Minhas Estatísticas</h1>
          <p className="text-slate-600 mt-2">
            Acompanhe seu progresso de leitura
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {/* Total de Capítulos */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Total de Capítulos</CardTitle>
                <BookOpen className="w-8 h-8 text-blue-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-blue-600">
                {totalChapters}
              </div>
              <p className="text-sm text-slate-600 mt-2">
                Capítulos disponíveis para leitura
              </p>
            </CardContent>
          </Card>

          {/* Marcadores */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Marcadores</CardTitle>
                <Heart className="w-8 h-8 text-red-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-red-600">
                {totalBookmarks}
              </div>
              <p className="text-sm text-slate-600 mt-2">
                Versículos marcados como favoritos
              </p>
            </CardContent>
          </Card>

          {/* Notas Pessoais */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Notas Pessoais</CardTitle>
                <BarChart3 className="w-8 h-8 text-green-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-green-600">
                {totalNotes}
              </div>
              <p className="text-sm text-slate-600 mt-2">
                Notas adicionadas em versículos
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Progresso de Leitura */}
        <Card>
          <CardHeader>
            <CardTitle>Resumo de Atividade</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-semibold text-slate-700">
                  Capítulos Explorados
                </span>
                <span className="text-sm text-slate-600">
                  {totalChapters > 0 ? "100%" : "0%"}
                </span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full"
                  style={{ width: "100%" }}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-semibold text-slate-700">
                  Engajamento com Marcadores
                </span>
                <span className="text-sm text-slate-600">
                  {totalBookmarks > 0 ? "Ativo" : "Sem marcadores"}
                </span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2">
                <div
                  className="bg-red-600 h-2 rounded-full"
                  style={{
                    width: totalBookmarks > 0 ? "60%" : "0%",
                  }}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-semibold text-slate-700">
                  Notas Pessoais
                </span>
                <span className="text-sm text-slate-600">
                  {totalNotes > 0 ? "Ativo" : "Sem notas"}
                </span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2">
                <div
                  className="bg-green-600 h-2 rounded-full"
                  style={{
                    width: totalNotes > 0 ? "40%" : "0%",
                  }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sugestões */}
        <Card className="mt-8 bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-900">Dicas para Melhor Aproveitamento</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-slate-700">
            <p>
              ✓ Explore todos os 24 capítulos para ter uma visão completa do Evangelho de Lucas
            </p>
            <p>
              ✓ Use marcadores para salvar versículos que tocam seu coração
            </p>
            <p>
              ✓ Adicione notas pessoais para refletir sobre os ensinamentos
            </p>
            <p>
              ✓ Use a busca avançada para encontrar versículos por tema
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
