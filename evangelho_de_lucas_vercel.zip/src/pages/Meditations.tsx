import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Heart, Lightbulb } from "lucide-react";
import { useState } from "react";

export default function Meditations() {
  const [, setLocation] = useLocation();
  const [savedMeditations, setSavedMeditations] = useState<number[]>([]);

  const meditations = [
    {
      day: 1,
      verse: "Lucas 1:37",
      text: "Porque para Deus nada é impossível.",
      meditation: "Qual é a impossibilidade que você está enfrentando? Reflita sobre como Deus pode transformar essa situação. Lembre-se de que Deus é onipotente e pode fazer o impossível possível. Confie em Seu poder e não em suas limitações.",
      reflection: "Você está confiando em Deus ou em suas próprias forças?",
      application: "Identifique uma situação impossível em sua vida e ore a Deus, confiando que Ele pode fazer o impossível.",
      prayer: "Senhor, ajuda-me a confiar em Teu poder infinito. Mesmo diante do impossível, quero crer que Tu podes fazer todas as coisas.",
    },
    {
      day: 2,
      verse: "Lucas 6:31",
      text: "Trata os outros da maneira como você gostaria de ser tratado.",
      meditation: "Este é o princípio fundamental de como devemos tratar os outros. Não é apenas uma regra ética, mas uma expressão do amor de Deus. Reflita sobre como você tem tratado os outros e se está aplicando este princípio.",
      reflection: "Como você gostaria de ser tratado? Está tratando os outros dessa forma?",
      application: "Hoje, trate alguém que normalmente ignoraria com kindness e respeito. Veja como essa atitude muda a dinâmica do relacionamento.",
      prayer: "Senhor, ajuda-me a tratar os outros com a mesma compaixão e respeito que desejo receber. Que meu amor pelos outros reflita Teu amor por mim.",
    },
    {
      day: 3,
      verse: "Lucas 12:34",
      text: "Pois onde está o seu tesouro, aí estará também o seu coração.",
      meditation: "O que você valoriza mais? Seu tesouro revela o que realmente importa para você. Se você valoriza riqueza, poder ou prestígio, seu coração estará focado nessas coisas. Se você valoriza Deus e Seu reino, seu coração estará focado em Deus.",
      reflection: "Onde está seu tesouro? O que você realmente valoriza na vida?",
      application: "Examine como você está gastando seu tempo, dinheiro e energia. Isso reflete seus verdadeiros valores ou você precisa realinhar suas prioridades com o reino de Deus?",
      prayer: "Senhor, ajuda-me a colocar meu tesouro em Ti e em Teu reino. Que meu coração esteja focado em coisas eternas, não em coisas temporais.",
    },
    {
      day: 4,
      verse: "Lucas 15:10",
      text: "Da mesma forma, há alegria diante dos anjos de Deus por um pecador que se arrepende.",
      meditation: "Deus se alegra quando um pecador se arrepende. Isso mostra que Deus valoriza cada pessoa e deseja sua salvação. Não importa quão longe você tenha ido, Deus está sempre pronto para recebê-lo de volta com alegria.",
      reflection: "Você acredita que Deus se alegra com seu arrependimento? Como isso muda sua perspectiva sobre a graça de Deus?",
      application: "Se você tem se afastado de Deus, hoje é o dia para se arrepender e voltar. Experimente a alegria que Deus tem quando você volta para Ele.",
      prayer: "Senhor, obrigado por estar sempre pronto para me receber. Ajuda-me a me arrepender de meus pecados e a experimentar a alegria de Teu perdão.",
    },
    {
      day: 5,
      verse: "Lucas 8:15",
      text: "Mas a semente no solo bom representa os que ouvem a palavra, a retêm de bom grado e produzem uma colheita pelo perseverar.",
      meditation: "Ser cristão não é apenas ouvir a Palavra de Deus, mas retê-la e permitir que ela produza fruto em sua vida. Isso requer perseverança e compromisso. Reflita sobre como você está permitindo que a Palavra de Deus transforme sua vida.",
      reflection: "Você está permitindo que a Palavra de Deus produza fruto em sua vida? Quais são os frutos que você está produzindo?",
      application: "Escolha um ensinamento de Jesus que você aprendeu recentemente e comprometa-se a aplicá-lo em sua vida esta semana.",
      prayer: "Senhor, ajuda-me a ser solo fértil para Tua Palavra. Que eu não apenas ouça, mas que eu retenha Tua Palavra e produza fruto abundante.",
    },
    {
      day: 6,
      verse: "Lucas 11:9",
      text: "Portanto, eu vos digo: Peçam, e lhes será dado; busquem, e encontrarão; batam, e a porta lhes será aberta.",
      meditation: "Deus quer que você peça, busque e bata à porta. Ele não está escondido ou relutante em responder. Deus é generoso e quer dar boas coisas aos Seus filhos. A questão é: você está pedindo?",
      reflection: "Qual é a maior oração em seu coração agora? Você tem pedido a Deus por isso?",
      application: "Hoje, apresente suas maiores necessidades e desejos a Deus em oração. Acredite que Ele ouvirá e responderá.",
      prayer: "Senhor, obrigado por me convidar a pedir. Ajuda-me a trazer meus pedidos a Ti com confiança, sabendo que Tu me ouves.",
    },
    {
      day: 7,
      verse: "Lucas 6:45",
      text: "O homem bom tira do bom tesouro do seu coração coisas boas; mas o homem mau tira do mau tesouro coisas más.",
      meditation: "Suas palavras e ações revelam o que está em seu coração. Se seu coração está cheio de boas coisas (amor, alegria, paz), você produzirá boas coisas. Se seu coração está cheio de coisas más (ódio, inveja, amargura), você produzirá coisas más.",
      reflection: "O que suas palavras e ações revelam sobre seu coração?",
      application: "Observe suas palavras e ações hoje. Elas revelam um coração cheio de coisas boas ou más? O que você precisa mudar?",
      prayer: "Senhor, limpa meu coração e enche-o com Tuas coisas boas. Que minhas palavras e ações reflitam um coração transformado por Teu amor.",
    },
  ];

  const toggleSaved = (index: number) => {
    if (savedMeditations.includes(index)) {
      setSavedMeditations(savedMeditations.filter((i) => i !== index));
    } else {
      setSavedMeditations([...savedMeditations, index]);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Meditações Diárias</h1>
          <p className="text-slate-600 mt-2">
            Versículos para refletir e aplicar na vida
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <Card className="bg-rose-50 border-rose-200">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <Heart className="w-8 h-8 text-rose-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-rose-900 mb-2">
                    Reflita e Transforme Sua Vida
                  </h3>
                  <p className="text-sm text-rose-800">
                    Cada meditação inclui um versículo, uma reflexão profunda, uma pergunta para refletir,
                    uma aplicação prática e uma oração para você meditar e transformar sua vida.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {meditations.map((meditation, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">
                      Dia {meditation.day}: {meditation.verse}
                    </CardTitle>
                    <p className="text-sm text-slate-600 mt-2 italic">
                      "{meditation.text}"
                    </p>
                  </div>
                  <button
                    onClick={() => toggleSaved(index)}
                    className="flex-shrink-0"
                  >
                    <Heart
                      className={`w-6 h-6 transition-colors ${
                        savedMeditations.includes(index)
                          ? "fill-rose-600 text-rose-600"
                          : "text-slate-400 hover:text-rose-600"
                      }`}
                    />
                  </button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Meditação</h4>
                  <p className="text-slate-700">{meditation.meditation}</p>
                </div>

                <div className="bg-rose-50 p-4 rounded-lg border-l-4 border-rose-600">
                  <p className="text-sm text-slate-700">
                    <span className="font-semibold">Pergunta para Refletir:</span>{" "}
                    {meditation.reflection}
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">
                    Aplicação Prática
                  </h4>
                  <p className="text-slate-700">{meditation.application}</p>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-600">
                  <p className="text-sm text-slate-700">
                    <span className="font-semibold">Oração:</span> {meditation.prayer}
                  </p>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const chapterNum = parseInt(meditation.verse.split(":")[0].split(" ")[1]);
                    setLocation(`/capitulos/${chapterNum}`);
                  }}
                >
                  Ler Capítulo Completo
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Card className="bg-gradient-to-r from-rose-50 to-pink-50 border-rose-200">
            <CardContent className="pt-8 pb-8">
              <Lightbulb className="w-12 h-12 text-rose-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                Transforme Sua Vida Através da Meditação
              </h3>
              <p className="text-slate-600 mb-6">
                Reserve um tempo cada dia para meditar sobre a Palavra de Deus e permitir que ela transforme seu coração.
              </p>
              <Button onClick={() => setLocation("/capitulos/1")}>
                Explorar os Capítulos
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
